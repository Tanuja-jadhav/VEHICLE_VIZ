<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: user_login.php");
    exit;
}
?>

<?php
error_reporting(0);
// Initialize variables
$success = $error = "";

// Database connection
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "details";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Form submission logic
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name           = trim($_POST['name']);
    $email          = trim($_POST['email']);
    $phone          = trim($_POST['phone']);
    $address        = trim($_POST['address']);
    $pickup_date    = $_POST['pickup_date'];
    $payment_method = $_POST['payment_method'];
    $notes          = trim($_POST['notes']);

    // Validate required fields
    if ($name && $email && $phone && $address && $pickup_date && $payment_method) {
        $stmt = $conn->prepare("INSERT INTO car_book (name, email, phone, address, pickup_date, payment_method, notes) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $name, $email, $phone, $address, $pickup_date, $payment_method, $notes);

        if ($stmt->execute()) {
            $last_id = $stmt->insert_id;
            $stmt->close();
            $conn->close();

            // Redirect to certificate page
            header("Location: certificate.php?id=$last_id");
            exit;
        } else {
            $error = "Error: " . $stmt->error;
            $stmt->close();
        }
    } else {
        $error = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Car Booking</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />
    <style>
        body {
            background-color: #2f2f2f;
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            color: #ddd;
        }
        .container {
            max-width: 600px;
            background: #d3d3d3;
            margin: 60px auto;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            color: #222;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #222;
        }
        label {
            display: block;
            margin: 12px 0 6px;
            font-weight: 700;
            color: #222;
        }
        input, textarea, select {
            width: 100%;
            padding: 12px;
            font-size: 15px;
            border-radius: 6px;
            border: 1px solid #999;
            box-sizing: border-box;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            color: #222;
            background: #f0f0f0;
        }
        input:focus, textarea:focus, select:focus {
            border-color: #555;
            box-shadow: 0 0 5px rgba(85, 85, 85, 0.5);
            outline: none;
            background: #fff;
        }
        select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D%2210%22%20height%3D%227%22%20viewBox%3D%220%200%2010%207%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cpath%20d%3D%22M0%200l5%207%205-7H0z%22%20fill%3D%22%23666%22/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 10px 7px;
            cursor: pointer;
        }
        button, .back-btn {
            margin-top: 25px;
            width: 100%;
            padding: 14px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            text-align: center;
            display: inline-block;
            text-decoration: none;
            box-sizing: border-box;
            transition: background 0.3s;
        }
        button {
            background: #28a745; /* green */
            color: #fff;
        }
        button:hover {
            background: #218838;
        }
        .back-btn {
            background: #007bff; /* blue */
            color: #fff;
            margin-top: 15px;
        }
        .back-btn:hover {
            background: #0056b3;
        }
        .message {
            margin-top: 15px;
            text-align: center;
            font-weight: 700;
        }
        .success {
            color: #28a745;
        }
        .error {
            color: #dc3545;
        }
        @media (max-width: 640px) {
            .container {
                margin: 30px 20px;
                padding: 25px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Book Your Car</h2>

    <?php if ($success): ?>
        <div class="message success"><?= htmlspecialchars($success) ?></div>
    <?php elseif ($error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" novalidate>
        <label for="name">Full Name *</label>
        <input type="text" name="name" id="name" required placeholder="Your full name" />

        <label for="email">Email Address *</label>
        <input type="email" name="email" id="email" required placeholder="example@mail.com" />

        <label for="phone">Phone Number *</label>
        <input type="text" name="phone" id="phone" required placeholder="+1 234 567 890" />

        <label for="address">Address *</label>
        <textarea name="address" id="address" rows="3" required placeholder="Your address"></textarea>

        <label for="pickup_date">Pickup Date *</label>
        <input type="date" name="pickup_date" id="pickup_date" required />

        <label for="payment_method">Payment Method *</label>
        <select name="payment_method" id="payment_method" required>
            <option value="" disabled selected>-- Select --</option>
            <option value="Cash">Cash</option>
            <option value="Credit Card">Credit Card</option>
            <option value="UPI">UPI</option>
        </select>

        <label for="notes">Additional Notes</label>
        <textarea name="notes" id="notes" rows="4" placeholder="Any preferences or comments..."></textarea>

        <button type="submit">Confirm Booking</button>
    </form>

    <!-- Back Button -->
    <a href="carlisting.php" class="back-btn" role="button">← Back to Car listing</a>
</div>

</body>
</html>
