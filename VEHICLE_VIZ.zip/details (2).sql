-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2025 at 07:09 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `details`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `ID` int(200) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `YEAR` varchar(300) NOT NULL,
  `IMAGE` varchar(300) NOT NULL,
  `DESCRIPTION` varchar(300) NOT NULL,
  `DETAILS` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`ID`, `NAME`, `YEAR`, `IMAGE`, `DESCRIPTION`, `DETAILS`) VALUES
(1, 'Toyota', '2025', 'jjdj', 'shdkj', 'jskk'),
(2, 'Thar', '2025', 'ghj', 'hsk', 'hklawe'),
(3, 'toyota', '2023', 'uploads/1753641841_background.png', 'hjkl', 'hkjl'),
(4, 'toyota', '2023', 'uploads/1753641868_msbtelogo.jpg', 'klj', 'uo'),
(5, 'toyota', '2023', 'uploads/1753641969_msbtelogo.jpg', 'jheka', 'ieoqwp');

-- --------------------------------------------------------

--
-- Table structure for table `car_loans`
--

CREATE TABLE `car_loans` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `loan_term` int(11) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car_loans`
--

INSERT INTO `car_loans` (`id`, `user_id`, `car_id`, `loan_amount`, `loan_term`, `interest_rate`, `status`, `created_at`) VALUES
(1, 1, 1, 1000000.00, 1, 1.00, 'pending', '2025-07-29 16:55:33'),
(2, 1, 1, 1000000.00, 1, 1.00, 'pending', '2025-07-29 17:06:30'),
(3, 1, 1, 1000000.00, 1, 1.00, 'pending', '2025-07-29 17:06:37'),
(4, 1, 1, 100000.00, 1, 1.00, 'pending', '2025-07-29 17:06:53'),
(6, 12, 123, 100000.00, 1, 12.00, 'pending', '2025-07-30 06:01:52'),
(7, 12, 12, 10000.00, 2, 2.00, 'pending', '2025-07-30 06:02:06'),
(8, 1, 2, 3.00, 4, 2.00, 'pending', '2025-07-30 06:04:50'),
(9, 1, 2, 3.00, 4, 2.00, 'pending', '2025-07-30 06:26:08'),
(10, 12, 21, 300000.00, 12, 13.00, 'pending', '2025-07-30 06:26:27'),
(11, 12, 21, 300000.00, 12, 13.00, 'pending', '2025-07-30 06:26:54'),
(12, 12, 21, 300000.00, 12, 13.00, 'pending', '2025-07-30 06:26:59'),
(13, 1, 1, 120000.00, 2, 3.00, 'pending', '2025-07-30 06:27:14'),
(14, 1, 1, 120000.00, 2, 3.00, 'pending', '2025-07-30 06:29:23'),
(15, 12, 21, 300000.00, 12, 13.00, 'pending', '2025-07-30 06:29:32'),
(16, 1, 2, 3.00, 4, 2.00, 'pending', '2025-07-30 06:38:35'),
(17, 1, 2, 3.00, 4, 2.00, 'pending', '2025-07-30 06:38:44'),
(18, 23, 23, 230000.00, 12, 12.00, 'pending', '2025-07-30 06:39:23'),
(19, 1, 12, 123.00, 12, 1.00, 'pending', '2025-07-30 06:52:33'),
(20, 1, 1, 123.00, 12, 1.00, 'pending', '2025-07-30 06:53:11');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`name`, `email`, `phone`, `dob`, `password`) VALUES
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '2147483647', '2025-07-02', '$2y$10$3Yylz/U45ucrErHorCfCVuS'),
('Dnyaneshwari Shelke', 'shelkednyaneshwari479@gmail.com', '2147483647', '2007-03-15', '$2y$10$qhT9RMTmZY5dnvPdfBe/u.L'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '2147483647', '2025-07-02', '$2y$10$wykqTgDkwdjBnvWdkylBj.m'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '09322671089', '2025-07-01', '$2y$10$T6zzjDGYZXEZAOIBoshNTOG'),
('Tanuja Jadhav', 'tanujajadhav11@gmail.com', '09322671089', '2025-07-07', '$2y$10$S8samHWwDL.MJcNQsR3hcOT'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '+919322671089', '2025-07-03', '$2y$10$VDTkKCX.J/WkWxwZO7qq.ug'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '+919322671089', '2025-07-03', '$2y$10$Ze4IOrlGTYNd71sYrV9m.uw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_details`
--
ALTER TABLE `car_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `car_loans`
--
ALTER TABLE `car_loans`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_details`
--
ALTER TABLE `car_details`
  MODIFY `ID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `car_loans`
--
ALTER TABLE `car_loans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
