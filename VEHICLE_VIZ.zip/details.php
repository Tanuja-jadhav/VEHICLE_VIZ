<!DOCTYPE html>
<html>
<head>
    <title>Car Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
            background: #eef2f3;
        }
        .details {
            background: white;
            padding: 30px;
            border-radius: 10px;
            width: 400px;
            margin: auto;
            box-shadow: 0 0 10px #ccc;
        }
        .details h2 {
            margin-bottom: 10px;
        }
        .details p {
            font-size: 16px;
        }
        .book-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: green;
            color: white;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<?php 
    
    <div class="details">
        <h2 id="carName">Car Name</h2>
        <p id="carDescription">Car Description</p>
        <p id="carPrice">Price</p>
        <button class="book-btn" onclick="bookCar()"><a href="invalid car name.html">Book Car</a></button>
    </div>

    <script>
        // Load car info from localStorage
        document.getElementById("carName").textContent = localStorage.getItem("carName");
        document.getElementById("carDescription").textContent = localStorage.getItem("carDescription");
        document.getElementById("carPrice").textContent = "Price: ₹" + localStorage.getItem("carPrice");

    ?>   
    </script>
</body>
</html>
