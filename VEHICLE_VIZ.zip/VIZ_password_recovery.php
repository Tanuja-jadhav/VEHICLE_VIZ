

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Recover Password</title>
  <style>
    body {
      background: #e3f2fd;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      width: 350px;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      text-align: center;
    }
    input, button {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #2196f3;
      color: white;
      font-weight: bold;
      border: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Password Recovery</h2>
    <p>Enter your email to receive an OTP</p>
    <form onsubmit="sendOtp(event)">
      <input type="email" id="email" placeholder="Enter your email" required />
      <button type="submit">Send OTP</button>
    </form>
  </div>

  <script>
    function sendOtp(e) {
      e.preventDefault();
      const email = document.getElementById('email').value;
      const otp = Math.floor(100000 + Math.random() * 900000); // Generate 6-digit OTP
      localStorage.setItem('otp', otp);
      alert("OTP sent to " + email + ": " + otp); // Simulate sending
      window.location.href = "VIZ_OTP.php";
    }
  </script>
</body>
</html>