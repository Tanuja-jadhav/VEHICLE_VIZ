<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Forgot Password</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Roboto', sans-serif;
    }

    body {
      background: linear-gradient(to right, #ff758c, #ff7eb3);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .recovery-container {
      background: white;
      padding: 2.5rem 3rem;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 400px;
      animation: slideIn 0.5s ease-in-out;
    }

    @keyframes slideIn {
      from {
        transform: translateY(20px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .recovery-container h2 {
      text-align: center;
      margin-bottom: 1rem;
      color: #333;
    }

    .recovery-container p {
      text-align: center;
      font-size: 0.95rem;
      color: #666;
      margin-bottom: 1.5rem;
    }

    .form-group {
      margin-bottom: 1.2rem;
    }

    .form-group label {
      display: block;
      font-size: 0.9rem;
      margin-bottom: 0.4rem;
      color: #444;
    }

    .form-group input {
      width: 100%;
      padding: 0.75rem 1rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 0.95rem;
      transition: 0.3s ease;
    }

    .form-group input:focus {
      border-color: #ff7eb3;
      outline: none;
      box-shadow: 0 0 5px rgba(255, 126, 179, 0.4);
    }

    .submit-btn {
      width: 100%;
      padding: 0.9rem;
      background-color: #ff7eb3;
      color: white;
      font-size: 1rem;
      font-weight: 500;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .submit-btn:hover {
      background-color: #ff679d;
    }

    .back-link {
      text-align: center;
      margin-top: 1.2rem;
      font-size: 0.9rem;
    }

    .back-link a {
      color: #ff7eb3;
      text-decoration: none;
      font-weight: 500;
    }

    .back-link a:hover {
      text-decoration: underline;
    }

    @media (max-width: 480px) {
      .recovery-container {
        padding: 2rem;
      }
    }
  </style>
</head>
<body>
  <div class="recovery-container">
    <h2>Forgot Password?</h2>
    <p>Enter your email and we'll send you a link to reset your password.</p>
    <form>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" placeholder="you@example.com" required>
      </div>
      <button type="submit" class="submit-btn">Send Recovery Email</button>
    </form>
    <div class="back-link">
      <p><a href="#">Back to Login</a></p>
    </div>
  </div>
</body>
</html>

