

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Car Management Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-image: url(https://mcdn.wallpapersafari.com/medium/61/86/SqyQCN.jpg);
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      color: white;
    }

    html {
      scroll-behavior: smooth;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(47, 54, 64, 0.95);
      padding: 10px 30px;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar .logo {
      font-size: 22px;
      font-weight: bold;
    }

    .navbar ul {
      display: flex;
      list-style: none;
      gap: 25px;
      margin: 0;
      padding: 0;
    }

    .navbar ul li a {
      color: white;
      text-decoration: none;
      transition: color 0.2s;
    }

    .navbar ul li a:hover {
      color: #00a8ff;
    }

    .auth-buttons button {
      background: #00a8ff;
      border: none;
      color: white;
      padding: 7px 15px;
      margin-left: 10px;
      border-radius: 4px;
      cursor: pointer;
    }

    .auth-buttons button:hover {
      background: #0090e0;
    }

    .main-content {
      padding: 50px 30px;
      background: rgba(0, 0, 0, 0.6);
    }

    .dashboard-cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 20px;
    }

    .card {
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      width: 22%;
      min-width: 220px;
      color: #000;
    }

    .card h3 {
      margin: 0;
      font-size: 18px;
    }

    .card p {
      font-size: 22px;
      margin-top: 10px;
      color: #007bff;
    }

    .modal {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
    }

    .modal-content {
      background: white;
      padding: 30px;
      border-radius: 8px;
      width: 90%;
      max-width: 400px;
      color: black;
    }

    .modal-content h2 {
      margin-top: 0;
    }

    .modal-content input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .modal-content button {
      width: 100%;
      padding: 10px;
      background: #00a8ff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .modal-content button:hover {
      background: #007bff;
    }

    .close-btn {
      float: right;
      cursor: pointer;
      font-size: 18px;
      color: #aaa;
    }

    .close-btn:hover {
      color: #333;
    }

    .about-us {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 50px 30px;
      margin-top: 40px;
      border-top: 1px solid rgba(255, 255, 255, 0.2);
    }

    .about-us h2 {
      color: #00a8ff;
      font-size: 30px;
      text-align: center;
      margin-bottom: 20px;
    }

    .about-us p {
      max-width: 800px;
      margin: auto;
      text-align: center;
      font-size: 18px;
      line-height: 1.6;
    }

    footer {
      text-align: center;
      padding: 20px;
      background: rgba(0, 0, 0, 0.7);
      font-size: 14px;
      color: #ccc;
      margin-top: 30px;
    }

    @media screen and (max-width: 768px) {
      .dashboard-cards {
        flex-direction: column;
        align-items: center;
      }
      .card {
        width: 90%;
      }
      .navbar ul {
        flex-direction: column;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

  <!-- Navigation -->
  <div class="navbar">
    <div class="logo">VK AUTO</div>
    <ul>
      <li><a href="carlisting.php"><i class="fas fa-car"></i> Vehicles</a></li>
      <li><a href="#rentals"><i class="fas fa-book"></i> Rentals</a></li>
      <li><a href="carmaintainance1.php"><i class="fas fa-tools"></i> Maintenance</a></li>
      <li><a href="#about"><i class="fas fa-info-circle"></i> About Us</a></li>
	  <li><a href="help.php"><i class="fas fa-info-circle"></i> Help</a></li>
	  <li><a href="contact.php"><i class="fas fa-info-circle"></i>contact</a></li>
    </ul>

    <div class="auth-buttons">
      <!--<button onclick="openModal('adminLogin')"><a href="adminlogin.php">Admin Login</a></button>
      <button onclick="openModal('userLogin')"><a href="user_login.php">User Login</a></button>-->
    </div>
  </div>

  <!-- Hero Heading -->
  <div class="main-content">
    <h1 style="font-size:60px; text-align:center;">VK AUTO</h1>
    <h2 style="font-size:40px; text-align:center;">Vehicle Management System</h2>

    <!-- Cards -->
    <div class="dashboard-cards">
      <div class="card">
        <h3>Total Vehicles</h3>
        <p>120</p>
      </div>
      <div class="card" id="rentals">
        <h3>Active Rentals</h3>
        <p>45</p>
      </div>
      <div class="card" id="maintenance">
        <h3>Maintenance</h3>
        <p>12</p>
      </div>
      <div class="card">
        <h3>Available Drivers</h3>
        <p>30</p>
      </div>
    </div>
  </div>

  <!-- About Us Section -->
  <div class="about-us" id="about">
    <h2>About VK AUTO</h2>
    <p>
      VK AUTO is a leading car rental and fleet management company offering a wide range of vehicles and services to customers across the country.
      Our mission is to deliver safe, reliable, and affordable transport solutions to both individuals and businesses. Whether you need a car for a day, a week, or long-term rental,
      VK AUTO provides seamless booking, maintenance support, and dedicated customer service. Your journey, our responsibility.
    </p>
  </div>

  <!-- Admin Login Modal -->
  <div class="modal" id="adminLogin">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal('adminLogin')">&times;</span>
      <a href="adminlogin.php"><h2>Admin Login</h2></a>
      <input type="text" placeholder="Username">
      <input type="password" placeholder="Password">
      <button>Login</button>
    </div>
  </div>

  <!-- User Login Modal -->
  <div class="modal" id="userLogin">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal('userLogin')">&times;</span>
      <h2><a href="user_login.php">User Login</a></h2>
      <input type="email" placeholder="Email">
      <input type="password" placeholder="Password">
      <button>Login</button>
    </div>
  </div>

  <!-- Footer -->
  <footer>
    &copy; 2025 VK AUTO. All rights reserved.
  </footer>

  <!-- JS for Modals -->