<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<h2>Employee Registered Successfully</h2>";

    echo "<p><strong>Employee ID:</strong> " . htmlspecialchars($_POST['employee_id']) . "</p>";
    echo "<p><strong>Name:</strong> " . htmlspecialchars($_POST['fullname']) . "</p>";
    echo "<p><strong>Email:</strong> " . htmlspecialchars($_POST['email']) . "</p>";
    echo "<p><strong>Phone:</strong> " . htmlspecialchars($_POST['phone']) . "</p>";
    echo "<p><strong>Date of Birth:</strong> " . htmlspecialchars($_POST['dob']) . "</p>";
    echo "<p><strong>Gender:</strong> " . htmlspecialchars($_POST['gender']) . "</p>";
    echo "<p><strong>Address:</strong> " . htmlspecialchars($_POST['address']) . "</p>";
    echo "<p><strong>Position:</strong> " . htmlspecialchars($_POST['position']) . "</p>";
    echo "<p><strong>Department:</strong> " . htmlspecialchars($_POST['department']) . "</p>";
    echo "<p><strong>Joining Date:</strong> " . htmlspecialchars($_POST['joining_date']) . "</p>";
} else {
    header("Location: index.php");
    exit;
}
