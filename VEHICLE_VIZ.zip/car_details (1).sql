-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2025 at 09:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `details`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `ID` int(200) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `YEAR` varchar(300) NOT NULL,
  `IMAGE` varchar(300) NOT NULL,
  `DESCRIPTION` varchar(300) NOT NULL,
  `DETAILS` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`ID`, `NAME`, `YEAR`, `IMAGE`, `DESCRIPTION`, `DETAILS`) VALUES
(1, 'Toyota', '2025', 'jjdj', 'shdkj', 'jskk'),
(2, 'Thar', '2025', 'ghj', 'hsk', 'hklawe'),
(3, 'toyota', '2023', 'uploads/1753641841_background.png', 'hjkl', 'hkjl'),
(4, 'toyota', '2023', 'uploads/1753641868_msbtelogo.jpg', 'klj', 'uo'),
(7, 'toyota', '2023', 'uploads/1754286762_msbtelogo.jpg', 'hjk', 'yuyi'),
(8, 'toyota', '2023', 'uploads/1754287069_msbtelogo.jpg', 'hjk', 'yuyi'),
(9, 'hyundai', '2025', 'uploads/1754287104_bg1.jpg', 'gjjh', 'gjjh'),
(10, 'hyundai', '2025', 'uploads/1754290753_bg1.jpg', 'gjjh', 'gjjh'),
(11, 'hyundai', '2022', 'uploads/1754290771_bg2.jpg', 'dhfjhkdj', 'jdkdkd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_details`
--
ALTER TABLE `car_details`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_details`
--
ALTER TABLE `car_details`
  MODIFY `ID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
