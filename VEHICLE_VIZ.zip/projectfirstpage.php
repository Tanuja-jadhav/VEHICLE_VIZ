

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Car Management Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-image: url('C:\Users\HP\Downloads\pexels-cesar-g-284432587-27845280.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-position: center;
      color: white;
    }

    html {
      scroll-behavior: smooth;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(47, 54, 64, 0.95);
      padding: 10px 30px;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .navbar .logo {
      font-size: 22px;
      font-weight: bold;
    }

    .auth-buttons button {
      background: #00a8ff;
      border: none;
      color: white;
      padding: 7px 15px;
      margin-left: 10px;
      border-radius: 4px;
      cursor: pointer;
    }

    .auth-buttons button:hover {
      background: #0090e0;
    }

    .main-content {
      padding: 50px 30px;
      background: rgba(0, 0, 0, 0.6);
    }

    .modal {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
    }

    .modal-content {
      background: white;
      padding: 30px;
      border-radius: 8px;
      width: 90%;
      max-width: 400px;
      color: black;
    }

    .modal-content h2 {
      margin-top: 0;
    }

    .modal-content input {
      width: 100%;
      padding: 10px;
      margin: 10px 0;
      border: 1px solid #ccc;
      border-radius: 4px;
    }

    .modal-content button {
      width: 100%;
      padding: 10px;
      background: #00a8ff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }

    .modal-content button:hover {
      background: #007bff;
    }

    .close-btn {
      float: right;
      cursor: pointer;
      font-size: 18px;
      color: #aaa;
    }

    .close-btn:hover {
      color: #333;
    }

    footer {
      text-align: center;
      padding: 20px;
      background: rgba(0, 0, 0, 0.7);
      font-size: 14px;
      color: #ccc;
      margin-top: 30px;
    }

    @media screen and (max-width: 768px) {
      .navbar {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>

  <!-- Navigation -->
  <div class="navbar">
    <div class="logo">VK AUTO</div>
    <div class="auth-buttons">
      <button onclick="openModal('adminLogin')">Admin Login</button>
      <button onclick="openModal('userLogin')">User Login</button>
    </div>
  </div>

  <!-- Hero Heading -->
  <div class="main-content">
    <h1 style="font-size:60px; text-align:center;">VK AUTO</h1>
    <h2 style="font-size:40px; text-align:center;">Vehicle Management System</h2>
  </div>

  <!-- Admin Login Modal -->
  <div class="modal" id="adminLogin">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal('adminLogin')">&times;</span>
      <h2><a href="adminlogin.php">Admin Login</a></h2>
      <input type="text" placeholder="Username">
      <input type="password" placeholder="Password">
      <button>Login</button>
    </div>
  </div>

  <!-- User Login Modal -->
  <div class="modal" id="userLogin">
    <div class="modal-content">
      <span class="close-btn" onclick="closeModal('userLogin')">&times;</span>
      <h2><a href="VIZ_login.php">User Login</a></h2>
      <input type="email" placeholder="Email">
      <input type="password" placeholder="Password">
      <button>Login</button>
    </div>
  </div>

  <footer>
    &copy; 2025 VK AUTO. All rights reserved.
  </footer>

  <script>
    function openModal(id) {
      document.getElementById(id).style.display = "flex";
    }

    function closeModal(id) {
      document.getElementById(id).style.display = "none";
    }

    window.onclick = function(event) {
      const modals = document.querySelectorAll('.modal');
      modals.forEach(modal => {
        if (event.target === modal) {
          modal.style.display = "none";
        }
      });
    }
  </script>

</body>
</html>
