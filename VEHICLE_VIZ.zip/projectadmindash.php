<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}
?>

<?php
$connection = mysqli_connect("localhost:3307", "root", "", "car_showroom");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}


// Hardcoded sample data
$totalVehicles = 120;
$totalSales = 85;
$totalCustomers = 60;
$totalRevenue = 1250000; // ₹12,50,000
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Vehicle Sales Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 15px;
    }
    .sidebar a:hover {
      background-color: #495057;
    }
    .card {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<div class="container-fluid">
 <body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 sidebar d-flex flex-column p-0">
        <h4 class="text-center mt-4">Admin Panel</h4>
        <a href="#">Dashboard</a>
        <a href="projectaddemployee.php">Manage Employee</a>
        <a href="vehiclerecord.php">Vehicle Record</a>
    
        <a href="projectvehiclemanage.php">Vehicle Management</a>
		 <a href="add_cars2.php">Add Vehicle</a>
		 <a href="projectadmincustomer.php">Customers</a>
		 <a href="projectadmincustomerrecord.php" class="block py-2 px-3 rounded hover:bg-gray-700 bg-gray-700">Customers Records</a>
        <a href="projectadminsold.php">Sold Vehicles</a>
		 <a href="projectadminloanrecord.php">Loan Application Record</a>
		
		 		 <a href="projectadminaddmaintainance.php">Maintainance</a>
				         <!-- Feedback Button -->
       
          <a href="admin_view_feedback.php">
             View Customer Feedback
          </a>
        

        <a href="adminlogout.php">Logout</a>
      </div>
      <!-- Main Content -->
      <div class="col-md-10 p-4">
        <h2>Dashboard</h2>
        <div class="row g-3 mt-3">
          <div class="col-md-3">
            <div class="card text-white bg-primary">
              <div class="card-body">
                <h5>Total Vehicles</h5>
                <h3><?php echo $totalVehicles; ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-success">
              <div class="card-body">
                <h5>Total Sales</h5>
                <h3><?php echo $totalSales; ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-warning">
              <div class="card-body">
                <h5>Customers</h5>
                <h3><?php echo $totalCustomers; ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card text-white bg-danger">
              <div class="card-body">
                <h5>Revenue</h5>
                <h3>₹<?php echo number_format($totalRevenue); ?></h3>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</body>
</html>
