<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: user_login.php");
    exit;
}
?>


<?php
// Enable error reporting (for development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$connection = new mysqli("localhost:3307", "root", "", "vehicle");
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $loan_amount = $_POST['loan_amount'];
    $loan_purpose = $_POST['loan_purpose'];

    $stmt = $connection->prepare("INSERT INTO loan_applications (full_name, email, phone, loan_amount, loan_purpose) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssds", $full_name, $email, $phone, $loan_amount, $loan_purpose);

    if ($stmt->execute()) {
        $message = '<div class="alert alert-success">Loan application submitted successfully!</div>';
    } else {
        $message = '<div class="alert alert-danger">Error: ' . $stmt->error . '</div>';
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Simple Loan Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h4>Loan Application Form</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($message)) echo $message; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" class="form-control" name="full_name" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email Address</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone Number</label>
                                <input type="text" class="form-control" name="phone">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Loan Amount (₹)</label>
                                <input type="number" step="0.01" class="form-control" name="loan_amount" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Loan Purpose</label>
                                <textarea class="form-control" name="loan_purpose" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn btn-success w-100 mb-3"><a href="UI.php">Submit Application</a></button>
                        </form>

                        <!-- Navigation Buttons -->
                        <div class="d-flex justify-content-between">
                            <a href="VIZ_loan_permission.php" class="btn btn-outline-secondary">← Back</a>
                            <a href="next_page.php" class="btn btn-outline-primary">Next →</a>
                        </div>
                    </div>
                    <div class="card-footer text-center text-muted">
                        &copy; <?php echo date('Y'); ?> Loan System
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

