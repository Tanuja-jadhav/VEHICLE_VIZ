

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Car-Themed Sign-Up Page</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    body, html {
      height: 100%;
    }

    body {
      background: url('https://spn-sta.spinny.com/blog/20220228142243/ezgif.com-gif-maker-98-5.jpg') no-repeat center center/cover;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
    }

    /* Dark overlay for readability */
    body::before {
      content: "";
      position: absolute;
      top: 0; left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.6);
      z-index: 1;
    }

    .signup-container {
      position: relative;
      z-index: 2;
      background: rgba(255, 255, 255, 0.9);
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
      width: 90%;
      max-width: 400px;
      backdrop-filter: blur(10px);
    }

    .signup-container h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #222;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
      color: #333;
    }

    .form-group input {
      width: 100%;
      padding: 12px 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
      outline: none;
      transition: 0.3s;
    }

    .form-group input:focus {
      border-color: #6C63FF;
      box-shadow: 0 0 5px rgba(108, 99, 255, 0.5);
    }

    .signup-btn {
      width: 100%;
      background: #6C63FF;
      color: white;
      padding: 12px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .signup-btn:hover {
      background: #4f45c5;
    }

    .login-link {
      text-align: center;
      margin-top: 15px;
      font-size: 14px;
    }

    .login-link a {
      color: #6C63FF;
      text-decoration: none;
      font-weight: 600;
    }

    .login-link a:hover {
      text-decoration: underline;
    }

    @media screen and (max-width: 500px) {
      .signup-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="signup-container">
    <h2>Create Your Account</h2>
    <form action="#" method="POST">
      <div class="form-group">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" required />
      </div>

      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" required />
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required />
      </div>

      <button type="submit" class="signup-btn">Sign Up</button>
    </form>
    <div class="login-link">
      Already have an account? <a href="#">Log in</a>
    </div>
  </div>
</body>
</html>
