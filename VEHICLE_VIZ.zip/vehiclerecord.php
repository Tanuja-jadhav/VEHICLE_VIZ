<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}

error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'errors.log');

// Database connection
$connection = mysqli_connect("localhost:3307", "root", "", "vehicle");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

$edit_mode = false;
$edit_data = [];

// Delete logic
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($connection, $_GET['delete']);
    mysqli_query($connection, "DELETE FROM car_inventory WHERE VEHICAL_ID = '$id'");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Edit mode logic
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = mysqli_real_escape_string($connection, $_GET['edit']);
    $result = mysqli_query($connection, "SELECT * FROM car_inventory WHERE VEHICAL_ID = '$edit_id'");
    $edit_data = mysqli_fetch_assoc($result);
}

// Update logic
if (isset($_POST['submit'])) {
    $ID = mysqli_real_escape_string($connection, $_POST['VEHICAL_ID']);
    $MODEL = mysqli_real_escape_string($connection, $_POST['MODEL_NAME']);
    $ADD_DATE = mysqli_real_escape_string($connection, $_POST['ADDING_DATE']);
    $SELL_DATE = mysqli_real_escape_string($connection, $_POST['SELLING_DATE']);
    $STATUS = mysqli_real_escape_string($connection, $_POST['STATUS']);

    $query = "UPDATE car_inventory SET 
                MODEL_NAME='$MODEL',
                ADDING_DATE='$ADD_DATE',
                SELLING_DATE='$SELL_DATE',
                STATUS='$STATUS'
              WHERE VEHICAL_ID='$ID'";
    mysqli_query($connection, $query);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Panel - Registered Vehicles</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex bg-gray-100 min-h-screen">

<!-- Sidebar -->
<aside class="w-64 bg-gray-800 text-white flex flex-col fixed h-screen">
    <div class="p-4 text-center font-bold text-lg border-b border-gray-700">
        Admin Panel
    </div>
    <nav class="flex-1 overflow-y-auto">
        <a href="dashboard.php" class="block px-4 py-2 hover:bg-gray-700">Dashboard</a>
        <a href="projectaddemployee.php" class="block px-4 py-2 hover:bg-gray-700">Manage Employee</a>
        <a href="vehiclerecord.php" class="block px-4 py-2 hover:bg-gray-700">Vehicle Record</a>
        <a href="projectvehiclemanage.php" class="block px-4 py-2 hover:bg-gray-700">Vehicle Management</a>
        <a href="add_cars2.php" class="block px-4 py-2 hover:bg-gray-700">Add Vehicle</a>
        <a href="projectadmincustomer.php" class="block px-4 py-2 hover:bg-gray-700">Customers</a>
        <a href="projectadmincustomerrecord.php" class="block px-4 py-2 bg-gray-700">Customers Records</a>
        <a href="projectadminsold.php" class="block px-4 py-2 hover:bg-gray-700">Sold Vehicles</a>
        <a href="projectadminloanrecord.php" class="block px-4 py-2 hover:bg-gray-700">Loan Applications</a>
        <a href="projectadminaddmaintainance.php" class="block px-4 py-2 hover:bg-gray-700">Maintenance</a>
        <a href="admin_view_feedback.php" class="block px-4 py-2 hover:bg-gray-700">View Customer Feedback</a>
    
    <a href="adminlogout.php" class="block px-4 py-2 hover:bg-gray-700">
        Logout
    </a>
	</nav>
</aside>

<!-- Main Content -->
<main class="flex-1 ml-64 p-8 space-y-6">
    <div class="flex justify-between items-center">
        <h2 class="text-2xl font-bold text-gray-700">📋 Registered Vehicles</h2>
        <a href="projectvehiclemanage.php" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 transition">
            + Add Vehicle
        </a>
    </div>

    <!-- Edit Form (shown only in edit mode) -->
    <?php if ($edit_mode): ?>
    <div class="bg-white shadow rounded-lg p-6">
        <h3 class="text-xl font-semibold mb-4 text-gray-800 text-center">✏️ Edit Vehicle</h3>
        <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input type="hidden" name="VEHICAL_ID" value="<?= $edit_data['VEHICAL_ID'] ?>">
            <input type="text" name="MODEL_NAME" placeholder="Model Name" value="<?= $edit_data['MODEL_NAME'] ?>" required class="border p-2 rounded">
            <input type="date" name="ADDING_DATE" value="<?= $edit_data['ADDING_DATE'] ?>" required class="border p-2 rounded">
            <input type="date" name="SELLING_DATE" value="<?= $edit_data['SELLING_DATE'] ?>" class="border p-2 rounded">
            <input type="text" name="STATUS" placeholder="Status" value="<?= $edit_data['STATUS'] ?>" required class="border p-2 rounded col-span-2">
            <button type="submit" name="submit" class="bg-gray-800 text-white py-2 px-4 rounded hover:bg-gray-900 col-span-2">
                Update Vehicle
            </button>
        </form>
    </div>
    <?php endif; ?>

    <!-- Table Section -->
    <div class="bg-white shadow rounded-lg p-4">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm text-center border border-gray-300">
                <thead class="bg-gray-200 text-gray-700">
                    <tr>
                        <th class="px-4 py-3 border">Vehicle ID</th>
                        <th class="px-4 py-3 border">Model Name</th>
                        <th class="px-4 py-3 border">Adding Date</th>
                        <th class="px-4 py-3 border">Selling Date</th>
                        <th class="px-4 py-3 border">Status</th>
                        <th class="px-4 py-3 border">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php
                    $result = mysqli_query($connection, "SELECT * FROM car_inventory");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr class='hover:bg-gray-50 transition'>";
                        echo "<td class='px-4 py-2 border'>{$row['VEHICAL_ID']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['MODEL_NAME']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['ADDING_DATE']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['SELLING_DATE']}</td>";
                        echo "<td class='px-4 py-2 border'>
                                <span class='inline-block px-3 py-1 rounded-full text-white " . 
                                ($row['STATUS'] == 'Sold' ? "bg-red-500" : "bg-green-500") . "'>
                                  {$row['STATUS']}
                                </span>
                              </td>";
                        echo "<td class='px-4 py-2 border'>
                                <a href='?edit={$row['VEHICAL_ID']}' class='text-yellow-600 hover:underline mx-2'>✏️ Edit</a>
                                <a href='?delete={$row['VEHICAL_ID']}' onclick=\"return confirm('Are you sure?');\" class='text-red-600 hover:underline mx-2'>🗑️ Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

</body>
</html>
