<?php
// Enable full error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to MySQL
$connection = mysqli_connect("localhost:3307", "root", "", "details");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $_POST['fullname'];
    $email    = $_POST['email'];
    $phone    = $_POST['phone'];
    $dob      = $_POST['dob'];
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if ($password !== $confirm) {
        echo "<script>alert('Passwords do not match.');</script>";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO user_details (name, email, phone, dob, password) 
                  VALUES ('$name', '$email', '$phone', '$dob', '$hashedPassword')";

        if (mysqli_query($connection, $query)) {
            // Redirect to login page after successful signup
            header("Location: VIZ_login.php");
            exit();
        } else {
            echo "<script>alert('Error: " . mysqli_error($connection) . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sign Up</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Segoe UI", sans-serif;
    }

    html, body {
      height: 100%;
      overflow: hidden;
    }

    body {
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(to right, #36d1dc, #5b86e5);
    }

    .signup-container {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(8px);
      padding: 25px 20px;
      border-radius: 15px;
      width: 100%;
      max-width: 380px;
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
    }

    .signup-container h2 {
      text-align: center;
      margin-bottom: 18px;
      font-size: 24px;
      color: #333;
    }

    .form-group {
      margin-bottom: 12px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-size: 14px;
      color: #444;
    }

    .form-group input {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      border: 1px solid #ccc;
      border-radius: 8px;
    }

    .form-group input:focus {
      border-color: #4e54c8;
      outline: none;
    }

    .signup-btn {
      width: 100%;
      padding: 11px;
      background: linear-gradient(to right, #4e54c8, #8f94fb);
      color: #fff;
      font-size: 15px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .signup-btn:hover {
      background: linear-gradient(to right, #3b41b0, #787ef5);
    }

    .bottom-text {
      margin-top: 10px;
      text-align: center;
      font-size: 13px;
      color: #555;
    }

    .bottom-text a {
      color: #4e54c8;
      text-decoration: none;
    }

    .bottom-text a:hover {
      text-decoration: underline;
    }

    @media (max-height: 600px) {
      .signup-container {
        transform: scale(0.94);
      }
    }
  </style>
</head>
<body>
  <form method="POST" action="">
    <div class="signup-container">
      <h2>Create Account</h2>

      <div class="form-group">
        <label for="fullname">Full Name</label>
        <input type="text" name="fullname" placeholder="John Doe" required />
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" name="email" placeholder="you@example.com" required />
      </div>

      <div class="form-group">
        <label for="phone">Phone</label>
        <input type="tel" name="phone" placeholder="1234567890" required />
      </div>

      <div class="form-group">
        <label for="dob">Date of Birth</label>
        <input type="date" name="dob" required />
      </div>

      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" name="password" placeholder="Enter password" required />
      </div>

      <div class="form-group">
        <label for="confirm">Confirm Password</label>
        <input type="password" name="confirm" placeholder="Repeat password" required />
      </div>

      <button type="submit" class="signup-btn"><a href="user_login.php">Sign Up</a></button>

      <div class="bottom-text">
        Already have an account? <a href="VIZ_login.php">Log in</a>
      </div>
    </div>
  </form>
</body>
</html>
