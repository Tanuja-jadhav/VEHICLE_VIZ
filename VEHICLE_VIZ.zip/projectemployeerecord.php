<?php
// Database connection
$connection = new mysqli("localhost:3307", "root", "", "vehicle");

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Handle DELETE
if (isset($_GET['delete'])) {
    $empId = $_GET['delete'];
    $connection->query("DELETE FROM employee WHERE EMPLOYEE_ID = $empId");
    header("Location: projectemployeerecord.php"); // change to your current filename
    exit();
}

// Handle EDIT form submission
if (isset($_POST['update'])) {
    $empId = $_POST['EMPLOYEE_ID'];
    $name = $_POST['EMPLOYEE_NAME'];
    $dob = $_POST['DOB'];
    $address = $_POST['ADDRESS'];
    $mobile = $_POST['MOBILE_NO'];
    $join = $_POST['JOIN_DATE'];
    $task = $_POST['TASK'];

    $connection->query("UPDATE employee SET EMPLOYEE_NAME='$name', DOB='$dob', ADDRESS='$address', MOBILE_NO='$mobile', JOIN_DATE='$join', TASK='$task' WHERE EMPLOYEE_ID=$empId");
    header("Location: projectemployeerecord.php");
    exit();
}

// Get employee for editing if needed
$editData = null;
if (isset($_GET['edit'])) {
    $empId = $_GET['edit'];
    $result = $connection->query("SELECT * FROM employee WHERE EMPLOYEE_ID = $empId");
    $editData = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Employee Record</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex min-h-screen bg-gray-100">

<!-- Sidebar -->
<div class="w-64 bg-gray-900 text-white p-6">
    <h1 class="text-2xl font-bold mb-8">🚗 Admin Panel</h1>
    <nav class="space-y-2">
        <a href="projectadmindash.php" class="block py-2 px-3 rounded hover:bg-gray-700">🏠 Dashboard</a>
        <a href="projectaddemployee.php" class="block py-2 px-3 rounded hover:bg-gray-700">👨‍💼 Manage Employee</a>
        <a href="vehiclerecord.php" class="block py-2 px-3 rounded bg-gray-700">🚘 Vehicle Record</a>
        <a href="projectvehiclemanage.php" class="block py-2 px-3 rounded hover:bg-gray-700">🛠 Vehicle Management</a>
        <a href="projectadmincustomer.php" class="block py-2 px-3 rounded hover:bg-gray-700">👥 Customers</a>
        <a href="projectadmincustomerrecord.php" class="block py-2 px-3 rounded hover:bg-gray-700">📋 Customer Records</a>
        <a href="projectadminsold.php" class="block py-2 px-3 rounded hover:bg-gray-700">🚗 Sold Vehicles</a>
        <a href="adminlogin.php" class="block py-2 px-3 rounded hover:bg-red-600">🚪 Logout</a>
    </nav>
</div>

<!-- Main Content -->
<div class="flex-1 p-8 space-y-6">
    <div class="flex justify-between items-center">
        <h2 class="text-2xl font-bold text-gray-700">📋 Employee Record</h2>
        <a href="projectaddemployee.php" class="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900 transition">
            + Add Employee
        </a>
    </div>

    <!-- Edit Form (if editing) -->
    <?php if ($editData): ?>
    <div class="bg-white p-6 rounded shadow">
        <h3 class="text-xl font-bold mb-4">✏️ Edit Employee</h3>
        <form method="POST">
            <input type="hidden" name="EMPLOYEE_ID" value="<?= $editData['EMPLOYEE_ID'] ?>">
            <div class="grid grid-cols-2 gap-4">
                <input type="text" name="EMPLOYEE_NAME" value="<?= $editData['EMPLOYEE_NAME'] ?>" placeholder="Name" class="border p-2 rounded" required>
                <input type="date" name="DOB" value="<?= $editData['DOB'] ?>" class="border p-2 rounded" required>
                <input type="text" name="ADDRESS" value="<?= $editData['ADDRESS'] ?>" placeholder="Address" class="border p-2 rounded" required>
                <input type="text" name="MOBILE_NO" value="<?= $editData['MOBILE_NO'] ?>" placeholder="Mobile No" class="border p-2 rounded" required>
                <input type="date" name="JOIN_DATE" value="<?= $editData['JOIN_DATE'] ?>" class="border p-2 rounded" required>
                <input type="text" name="TASK" value="<?= $editData['TASK'] ?>" placeholder="Task" class="border p-2 rounded" required>
            </div>
            <div class="mt-4">
                <button type="submit" name="update" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Update</button>
                <a href="projectemployeerecord.php" class="ml-4 text-gray-600 hover:underline">Cancel</a>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- Table Section -->
    <div class="bg-white shadow rounded-lg p-4">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm text-center border border-gray-300">
                <thead class="bg-gray-200 text-gray-700">
                    <tr>
                        <th class="px-4 py-3 border">EMPLOYEE_ID</th>
                        <th class="px-4 py-3 border">EMPLOYEE_NAME</th>
                        <th class="px-4 py-3 border">DOB</th>
                        <th class="px-4 py-3 border">ADDRESS</th>
                        <th class="px-4 py-3 border">MOBILE_NO</th>
                        <th class="px-4 py-3 border">JOIN DATE</th>
                        <th class="px-4 py-3 border">TASK</th>
                        <th class="px-4 py-3 border">ACTIONS</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php
                    $result = $connection->query("SELECT * FROM employee");
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr class='hover:bg-gray-50 transition'>";
                        echo "<td class='px-4 py-2 border'>{$row['EMPLOYEE_ID']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['EMPLOYEE_NAME']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['DOB']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['ADDRESS']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['MOBILE_NO']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['JOIN_DATE']}</td>";
                        echo "<td class='px-4 py-2 border'>{$row['TASK']}</td>";
                        echo "<td class='px-4 py-2 border'>
                                <a href='?edit={$row['EMPLOYEE_ID']}' class='text-yellow-600 hover:underline mx-2'>✏️ Edit</a>
                                <a href='?delete={$row['EMPLOYEE_ID']}' onclick=\"return confirm('Are you sure?');\" class='text-red-600 hover:underline mx-2'>🗑️ Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>

