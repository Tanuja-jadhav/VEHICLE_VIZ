-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2025 at 08:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `details`
--

-- --------------------------------------------------------

--
-- Table structure for table `car_details`
--

CREATE TABLE `car_details` (
  `ID` int(200) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `YEAR` varchar(300) NOT NULL,
  `IMAGE` varchar(300) NOT NULL,
  `DESCRIPTION` varchar(300) NOT NULL,
  `DETAILS` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car_details`
--

INSERT INTO `car_details` (`ID`, `NAME`, `YEAR`, `IMAGE`, `DESCRIPTION`, `DETAILS`) VALUES
(1, 'Toyota', '2025', 'jjdj', 'shdkj', 'jskk'),
(2, 'Thar', '2025', 'ghj', 'hsk', 'hklawe'),
(3, 'toyota', '2023', 'uploads/1753641841_background.png', 'hjkl', 'hkjl'),
(4, 'toyota', '2023', 'uploads/1753641868_msbtelogo.jpg', 'klj', 'uo'),
(5, 'toyota', '2023', 'uploads/1753641969_msbtelogo.jpg', 'jheka', 'ieoqwp');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`name`, `email`, `phone`, `dob`, `password`) VALUES
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '2147483647', '2025-07-02', '$2y$10$3Yylz/U45ucrErHorCfCVuS'),
('Dnyaneshwari Shelke', 'shelkednyaneshwari479@gmail.com', '2147483647', '2007-03-15', '$2y$10$qhT9RMTmZY5dnvPdfBe/u.L'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '2147483647', '2025-07-02', '$2y$10$wykqTgDkwdjBnvWdkylBj.m'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '09322671089', '2025-07-01', '$2y$10$T6zzjDGYZXEZAOIBoshNTOG'),
('Tanuja Jadhav', 'tanujajadhav11@gmail.com', '09322671089', '2025-07-07', '$2y$10$S8samHWwDL.MJcNQsR3hcOT'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '+919322671089', '2025-07-03', '$2y$10$VDTkKCX.J/WkWxwZO7qq.ug'),
('Tanuja Jadhav', 'tanujajadhav012@gmail.com', '+919322671089', '2025-07-03', '$2y$10$Ze4IOrlGTYNd71sYrV9m.uw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `car_details`
--
ALTER TABLE `car_details`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `car_details`
--
ALTER TABLE `car_details`
  MODIFY `ID` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
