<?php
// feedback_form.php
$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $conn = new mysqli("localhost:3307", "root", "", "feedback_system");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username       = htmlspecialchars($_POST["username"]);
    $email          = htmlspecialchars($_POST["email"]);
    $contact_number = htmlspecialchars($_POST["contact_number"]);
    $subject        = htmlspecialchars($_POST["subject"]);
    $rating         = intval($_POST["rating"]);
    $message        = htmlspecialchars($_POST["message"]);

    $sql = "INSERT INTO feedback (username, email, contact_number, subject, rating, message)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssis", $username, $email, $contact_number, $subject, $rating, $message);

    if ($stmt->execute()) {
        $success = "✅ Feedback submitted successfully!";
    } else {
        $error = "❌ Something went wrong. Try again.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Feedback Form</title>
  <style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f4f4;
        padding: 40px;
    }
    .form-container {
        max-width: 600px;
        margin: auto;
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 0 10px #ccc;
    }
    input, textarea, select {
        width: 100%;
        padding: 12px;
        margin: 10px 0;
        border-radius: 5px;
        border: 1px solid #ccc;
    }
    button {
        padding: 12px 25px;
        background: green;
        color: white;
        border: none;
        cursor: pointer;
        border-radius: 5px;
    }
    .back-btn {
        display: inline-block;
        padding: 10px 20px;
        background: #555;
        color: white;
        text-decoration: none;
        border-radius: 5px;
    }
    .back-btn:hover {
        background: #333;
    }
    .center {
        text-align: center;
        margin-top: 20px;
    }
    .message {
        color: green;
        font-weight: bold;
        margin-bottom: 10px;
    }
    .error {
        color: red;
        font-weight: bold;
    }
  </style>
</head>
<body>

<div class="form-container">
    <h2>📬 Submit Feedback</h2>

    <div id="statusMessage"></div> <!-- For innerHTML message -->

    <?php if ($success): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("statusMessage").innerHTML = "<div class='message'>✅ Your form is filled successfully!</div>";
            });
        </script>
    <?php elseif ($error): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("statusMessage").innerHTML = "<div class='error'>❌ Something went wrong. Try again.</div>";
            });
        </script>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Name:</label>
        <input type="text" name="username" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Contact Number:</label>
        <input type="text" name="contact_number" required>

        <label>Subject:</label>
        <input type="text" name="subject" required>

        <label>Rating:</label>
        <select name="rating" required>
            <option value="">-- Select Rating --</option>
            <option value="5">Excellent ⭐⭐⭐⭐⭐</option>
            <option value="4">Very Good ⭐⭐⭐⭐</option>
            <option value="3">Good ⭐⭐⭐</option>
            <option value="2">Fair ⭐⭐</option>
            <option value="1">Poor ⭐</option>
        </select>

        <label>Message:</label>
        <textarea name="message" rows="5" required></textarea>

        <button type="submit">Submit Feedback</button>
    </form>

    <div class="center">
        <a href="UI.php" class="back-btn">⬅ Back</a>
    </div>
</div>

</body>
</html>
