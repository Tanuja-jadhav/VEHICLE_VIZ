<?php
// login_process.php

session_start();

// Dummy credentials
$valid_username = "admin";
$valid_password = "password";

if ($_POST['username'] === $valid_username && $_POST['password'] === $valid_password) {
    $_SESSION['loggedin'] = true;
    header("Location: employee_registration.php");
    exit();
} else {
    echo "<script>alert('Invalid Credentials'); window.location.href='login.php';</script>";
    exit();
}
