<?php
// Hide errors from displaying in browser
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 0);

// Optional: Log errors to a file
ini_set('log_errors', 1);
ini_set('error_log', 'errors.log');

// Connect to MySQL
$connection = mysqli_connect("localhost:3307", "root", "", "showroom");
if (!$connection) {
    error_log("Database connection failed: " . mysqli_connect_error());
    die("Connection error. Please try again later.");
}

// Handle Add Record
if (isset($_POST['add'])) {
    $vehicle_id = mysqli_real_escape_string($connection, $_POST['vehicle_id']);
    $service_date = mysqli_real_escape_string($connection, $_POST['service_date']);
    $service_type = mysqli_real_escape_string($connection, $_POST['service_type']);
    $cost = mysqli_real_escape_string($connection, $_POST['cost']);
    $notes = mysqli_real_escape_string($connection, $_POST['notes']);

    $query = "INSERT INTO car_maintenance (Vehicle_Id, Date, Service, Cost, Notes)
              VALUES ('$vehicle_id', '$service_date', '$service_type', '$cost', '$notes')";

    if (!mysqli_query($connection, $query)) {
        error_log("Error inserting record: " . mysqli_error($connection));
    }

    header("Location: maintenance.php");
    exit;
}

// Handle Delete Record
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $deleteQuery = "DELETE FROM car_maintenance WHERE ID = $id";

    if (!mysqli_query($connection, $deleteQuery)) {
        error_log("Error deleting record: " . mysqli_error($connection));
    }

    header("Location: maintenance.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Car Maintenance Management</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #d6d8db, #f2f2f2);
      padding: 30px;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: #f9f9f9;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 12px rgba(0,0,0,0.08);
    }

    h2 {
      color: #333;
      margin-bottom: 20px;
    }

    .back-button {
      padding: 10px 20px;
      background-color: #10b981; /* Green */
      color: white;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
      margin-bottom: 20px;
      transition: background-color 0.3s ease;
    }

    .back-button:hover {
      background-color: #059669; /* Darker green on hover */
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    table th, table td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    table th {
      background-color: #e5e7eb;
      color: #111827;
    }

    .delete-btn {
      color: #dc2626;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
    }

    .delete-btn:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="container">
    <h2>Car Maintenance Management</h2>

    <!-- Back Button -->
    <button class="back-button" onclick="window.location.href='UI.php'">← Back</button>

    <!-- Maintenance Records Table -->
    <h3>Maintenance Records</h3>
    <table>
      <thead>
        <tr>
          <th>Vehicle ID</th>
          <th>Date</th>
          <th>Service</th>
          <th>Cost</th>
          <th>Notes</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = mysqli_query($connection, "SELECT * FROM car_maintenance");
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['Vehicle_Id']}</td>";
                echo "<td>{$row['Date']}</td>";
                echo "<td>{$row['Service']}</td>";
                echo "<td>$" . number_format($row['Cost'], 2) . "</td>";
                echo "<td>{$row['Notes']}</td>";
                echo "<td><a class='delete-btn' href='?delete={$row['ID']}' onclick=\"return confirm('Delete this record?');\">Delete</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No records found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>
