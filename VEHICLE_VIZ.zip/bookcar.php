<!DOCTYPE html>
<html>
<head>
    <title>Car Details</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        .car-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            width: 350px;
            overflow: hidden;
            text-align: center;
            padding-bottom: 20px;
        }

        .car-card img {
            width: 100%;
            height: auto;
        }

        .car-card h3 {
            margin: 15px 0 10px;
            color: #333;
        }

        .car-card p {
            margin: 5px 20px;
            font-size: 15px;
            color: #555;
        }

        .book-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #2e86de;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
        }

        .book-btn:hover {
            background-color: #1b4f9c;
        }
    </style>
</head>
<body>

    <div class="car-card">
        <img src="https://imgd.aeplcdn.com/370x208/n/qv5knta_1500713.jpg?q=80" alt="Toyota Fortuner">
        <h3>Toyota Fortuner</h3>
        <p><strong>Price:</strong> ₹35,00,000</p>
        <p><strong>Fuel Type:</strong> Diesel</p>
        <p><strong>Transmission:</strong> Automatic</p>
        <p><strong>Mileage:</strong> 10.0 km/l</p>
        <p><strong>Seating Capacity:</strong> 7 Seater</p>

        <a href="invalid car name.php" class="book-btn">Book Now</a>
    </div>

</body>
</html>
