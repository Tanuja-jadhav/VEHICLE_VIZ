<?php
// Get details from URL
$name = $_GET['name'] ?? 'Unknown Car';
$image = $_GET['image'] ?? '';
$description = $_GET['description'] ?? 'No description available.';
$price = $_GET['price'] ?? 'Not available.';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Details - <?= htmlspecialchars($name) ?></title>
    <style>
        body { font-family: Arial; margin: 0; padding: 20px; text-align: center; }
        .container { max-width: 700px; margin: auto; border: 1px solid #ccc; padding: 20px; border-radius: 10px; }
        img { width: 100%; max-height: 350px; object-fit: cover; border-radius: 10px; }
        .details { margin-top: 20px; text-align: left; }
        .details h2 { margin-bottom: 10px; }
        button { margin-top: 20px; padding: 10px 20px; font-size: 16px; background: green; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background-color: darkgreen; }
    </style>
</head>
<body>

    <div class="container">
        <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($name) ?>">
        <div class="details">
            <h2><?= htmlspecialchars($name) ?></h2>
            <p><strong>Description:</strong> <?= htmlspecialchars($description) ?></p>
            <p><strong>Price:</strong> <?= htmlspecialchars($price) ?></p>
        </div>
        <a href="bookcar.php?name=<?= urlencode($name) ?>">
            <button>Book Now</button>
        </a>
    </div>

</body>
</html>
