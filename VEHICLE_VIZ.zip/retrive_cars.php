
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM car_details";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Car Showcase</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Base styling */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f2f5;
            color: #333;
            line-height: 1.6;
        }

        header {
            background: linear-gradient(to right, #004e92, #000428);
            color: #fff;
            padding: 40px 20px;
            text-align: center;
        }

        header h1 {
            margin-bottom: 10px;
            font-size: 2.5em;
        }

        header p {
            font-size: 1.1em;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
        }

        .card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            width: 300px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .card img:hover {
            transform: scale(1.05);
        }

        .card-content {
            padding: 20px;
        }

        .card-content h2 {
            font-size: 1.2em;
            margin-bottom: 10px;
            color: #222;
        }

        .card-content .description {
            font-size: 14px;
            color: #555;
            margin-bottom: 10px;
        }

        .card-content .details {
            font-size: 13px;
            color: #777;
        }

        footer {
            text-align: center;
            padding: 20px;
            font-size: 14px;
            color: #666;
            background-color: #eaeaea;
            margin-top: 40px;
        }

        .no-data {
            text-align: center;
            font-size: 18px;
            margin-top: 40px;
            color: #999;
        }
    </style>
</head>
<body>

<header>
    <h1>🚗 Car Showcase</h1>
    <p>Explore our collection of stunning rides</p>
</header>

<div class="container">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            ?>
            <div class="card">
                <img src="<?php echo htmlspecialchars($row['IMAGE']); ?>" alt="Car Image">
                <div class="card-content">
                    <h2><?php echo htmlspecialchars($row['NAME']) . " (" . htmlspecialchars($row['YEAR']) . ")"; ?></h2>
                    <p class="description"><?php echo nl2br(htmlspecialchars($row['DESCRIPTION'])); ?></p>
                    <p class="details"><?php echo nl2br(htmlspecialchars($row['DETAILS'])); ?></p>
                </div>
            </div>
            <?php
        }
    } else {
        echo "<p class='no-data'>No car data found.</p>";
    }
    $conn->close();
    ?>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Car Showcase
</footer>

</body>
</html>
