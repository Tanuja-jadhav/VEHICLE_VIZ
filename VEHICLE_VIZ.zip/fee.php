<!-- Back Button -->
    <a href="carlisting.php" class="back-btn" role="button">← Back to Car listing</a>

    <!-- Feedback Button -->
    <a href="feedback.php" class="feedback-btn" role="button">💬 Give Feedback</a>
</div>

<style>
    .feedback-btn {
        background: #ff9800; /* orange */
        color: #fff;
        display: block;
        margin-top: 15px;
        padding: 14px;
        font-size: 16px;
        border-radius: 8px;
        text-align: center;
        text-decoration: none;
        transition: background 0.3s;
    }
    .feedback-btn:hover {
        background: #e68900;
    }
</style>