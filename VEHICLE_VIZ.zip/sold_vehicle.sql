-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 31, 2025 at 01:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_showroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `sold_vehicle`
--

CREATE TABLE `sold_vehicle` (
  `VEHICLE_ID` int(10) NOT NULL,
  `NAME` varchar(200) NOT NULL,
  `BRAND` varchar(300) NOT NULL,
  `PRICE` int(20) NOT NULL,
  `IMAGE_PATH` varchar(300) NOT NULL,
  `STATUS` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sold_vehicle`
--

INSERT INTO `sold_vehicle` (`VEHICLE_ID`, `NAME`, `BRAND`, `PRICE`, `IMAGE_PATH`, `STATUS`) VALUES
(1, 'Swift DZire', 'Maruti', 750000, 'https://imgd.aeplcdn.com/664x374/n/cw/ec/45691/dzire-exterior-right-front-three-quarter-3.jpeg?isig=0&q=80', 'Sold'),
(2, 'i20 Sportz', 'Hyundai', 880000, 'https://trident-group.s3.ap-south-1.amazonaws.com/hyundai/models/colors/1698928901.png', 'Sold'),
(3, 'Brezza ZXI', 'Maruti', 1200000, 'https://img-new.cgtrader.com/items/3584066/0e9bcedb8f/large/suzuki-brezza-2021-3d-model-max.jpg', 'sold'),
(4, 'Honda City VX', 'Honda', 1350000, 'https://media.drive.com.au/obj/tx_rs:auto:1920:1080:1/caradvice/private/698707093c34c665316cdf4659a4cc55', 'Sold');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sold_vehicle`
--
ALTER TABLE `sold_vehicle`
  ADD PRIMARY KEY (`VEHICLE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sold_vehicle`
--
ALTER TABLE `sold_vehicle`
  MODIFY `VEHICLE_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
