<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: user_login.php");
    exit;
}
?>


<?php
// bookcar.php
error_reporting(0);
// Database connection
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "details";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$car = null;

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM car_bookings WHERE ID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $car = $result->fetch_assoc();
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Car Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #2f2f2f; /* Dark gray background only */
            margin: 0;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 40px auto;
            background: #fff; /* White container */
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            color: #333;
        }

        .header {
            background: #2c3e50;
            color: #fff;
            padding: 25px;
            text-align: center;
        }

        .car-body {
            display: flex;
            flex-wrap: wrap;
            padding: 30px;
        }

        .car-img {
            flex: 1 1 40%;
            padding-right: 30px;
        }

        .car-img img {
            width: 100%;
            border-radius: 10px;
            object-fit: cover;
        }

        .car-info {
            flex: 1 1 60%;
        }

        .car-info h2 {
            margin-top: 0;
            color: #333;
        }

        .car-info p {
            margin: 10px 0;
        }

        .label {
            font-weight: bold;
            color: #2c3e50;
        }

        .back-btn,
        .book-btn {
            display: inline-block;
            margin: 20px 10px;
            padding: 12px 24px;
            background: #3498db;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            width: 200px;
        }

        .book-btn {
            background: #27ae60;
        }

        .book-btn:hover {
            background: #1e8449;
        }

        .back-btn:hover {
            background: #2980b9;
        }

        .btn-container {
            text-align: center;
        }

        footer {
            text-align: center;
            padding: 15px;
            background: #eee;
            margin-top: 30px;
        }

        @media (max-width: 700px) {
            .car-body {
                flex-direction: column;
            }
            .car-img, .car-info {
                flex: 1 1 100%;
                padding-right: 0;
            }
            .btn-container a {
                width: 100%;
                margin: 8px 0;
            }
        }
    </style>
</head>
<body>

<?php if ($car): ?>
    <div class="container">
        <div class="header">
            <?= htmlspecialchars($car['NAME']) ?> - <?= htmlspecialchars($car['YEAR']) ?>
        </div>
        <div class="car-body">
            <div class="car-img">
                <img src="<?= htmlspecialchars($car['IMAGE']) ?>" alt="Car Image" />
            </div>
            <div class="car-info">
                <h2>Description</h2>
                <p><?= nl2br(htmlspecialchars($car['DESCRIPTION'])) ?></p>

                <h2>Details</h2>
                <p><?= nl2br(htmlspecialchars($car['DETAILS'])) ?></p>

                <h2>Specifications</h2>
                <p><span class="label">Accident:</span> <?= htmlspecialchars($car['ACCIDENT']) ?></p>
                <p><span class="label">Tyres:</span> <?= htmlspecialchars($car['TYRES']) ?></p>
                <p><span class="label">Scratch:</span> <?= htmlspecialchars($car['SCRATCH']) ?></p>
                <p><span class="label">Door Seal:</span> <?= htmlspecialchars($car['DOOR_SEAL']) ?></p>
                <p><span class="label">Engine:</span> <?= htmlspecialchars($car['ENGINE']) ?></p>
                <p><span class="label">Servicing:</span> <?= htmlspecialchars($car['SERVICING']) ?></p>
                <p><span class="label">Remaining Material:</span> <?= nl2br(htmlspecialchars($car['REMAINING_MATERIAL'])) ?></p>
            </div>
        </div>
    </div>

    <div class="btn-container">
        <a class="book-btn" href="booking_form.php?id=<?= $car['ID'] ?>">Book Now</a>
        <a class="back-btn" href="carlisting.php">← Back to Car Listing</a>
    </div>
<?php else: ?>
    <div class="container">
        <div class="header">
            Car Not Found
        </div>
        <div class="car-body">
            <p style="padding: 20px;">Sorry, no car found for the given ID.</p>
            <div class="btn-container">
                <a class="back-btn" href="carlisting.php">← Back to Car Listing</a>
            </div>
        </div>
    </div>
<?php endif; ?>

<footer>
    &copy; <?= date("Y") ?> Vehicle Management System
</footer>

</body>
</html>
