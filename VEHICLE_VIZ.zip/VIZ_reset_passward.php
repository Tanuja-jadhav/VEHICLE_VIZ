

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <style>
    body {
      background: #fff3e0;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      width: 350px;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      text-align: center;
    }
    input, button {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #ff9800;
      color: white;
      font-weight: bold;
      border: none;
    }
    #message {
      color: green;
      margin-top: 10px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Reset Your Password</h2>
    <form onsubmit="resetPassword(event)">
      <input type="password" id="pass1" placeholder="New Password" required />
      <input type="password" id="pass2" placeholder="Confirm Password" required />
      <button type="submit" >Update Password</button>
      <p id="message"></p>
    </form>
  </div>

  <script>
    function resetPassword(e) {
      e.preventDefault();
      const pass1 = document.getElementById('pass1').value;
      const pass2 = document.getElementById('pass2').value;
      const msg = document.getElementById('message');

      if (pass1 !== pass2) {
        msg.style.color = "red";
        msg.innerText = "Passwords do not match!";
      } else {
        msg.style.color = "green";
        msg.innerText = "Password reset successfully!";
		//echo"Password reset successfully!";
		window.location.href="VIZ_loan_permission.php";
        localStorage.removeItem('otp'); // Optional cleanup
      }
    }
  </script>
</body>
</html>