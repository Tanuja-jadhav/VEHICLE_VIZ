<?php
 //Hide errors from displaying in browser
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 0);

// Optional: Log errors to a file (enable only if needed)
ini_set('log_errors', 1);
ini_set('error_log', 'errors.log');

// Connect to MySQL
$connection = mysqli_connect("localhost:3307", "root", "", "showroom");
if (!$connection) {
    error_log("Database connection failed: " . mysqli_connect_error());
    die("Connection error. Please try again later.");
}

// Handle Add Record
if (isset($_POST['add'])) {
    $vehicle_id = mysqli_real_escape_string($connection, $_POST['vehicle_id']);
    $service_date = mysqli_real_escape_string($connection, $_POST['service_date']);
    $service_type = mysqli_real_escape_string($connection, $_POST['service_type']);
    $cost = mysqli_real_escape_string($connection, $_POST['cost']);
    $notes = mysqli_real_escape_string($connection, $_POST['notes']);

    $query = "INSERT INTO car_maintenance (Vehicle_Id, Date, Service, Cost, Notes)
              VALUES ('$vehicle_id', '$service_date', '$service_type', '$cost', '$notes')";

    if (!mysqli_query($connection, $query)) {
        error_log("Error inserting record: " . mysqli_error($connection));
    }

    header("Location: maintenance.php");
    exit;
}

// Handle Delete Record
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $deleteQuery = "DELETE FROM car_maintenance WHERE ID = $id";

    if (!mysqli_query($connection, $deleteQuery)) {
        error_log("Error deleting record: " . mysqli_error($connection));
    }

    header("Location: maintenance.php"); // ✅ Fixed redirect
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Car Maintenance Management</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f3f4f6;
      padding: 20px;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      color: #4f46e5;
      margin-bottom: 20px;
    }

    form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
      margin-bottom: 30px;
    }

    form textarea {
      grid-column: span 2;
      resize: vertical;
      height: 80px;
    }

    form button {
      grid-column: span 2;
      padding: 10px;
      background-color: #4f46e5;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }

    input, textarea {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      width: 100%;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    table th, table td {
      padding: 12px;
      border: 1px solid #ddd;
      text-align: left;
    }

    table th {
      background-color: #e0e7ff;
      color: #1e3a8a;
    }

    .delete-btn {
      color: #dc2626;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
    }

    .delete-btn:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <!--<div class="container">
    <h2>Car Maintenance Management</h2>

  
    <form method="POST">
      <input type="text" name="vehicle_id" placeholder="Vehicle ID" required>
      <input type="date" name="service_date" required>
      <input type="text" name="service_type" placeholder="Service Type" required>
      <input type="number" step="0.01" name="cost" placeholder="Cost (e.g., 150.00)" required>
      <textarea name="notes" placeholder="Notes (optional)"></textarea>
      <button type="submit" name="add">Add Maintenance Record</button>
    </form>-->

    <!-- Records Table -->
    <h3>Maintenance Records</h3>
    <table>
      <thead>
        <tr>
          <th>Vehicle ID</th>
          <th>Date</th>
          <th>Service</th>
          <th>Cost</th>
          <th>Notes</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $result = mysqli_query($connection, "SELECT * FROM car_maintenance");
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>{$row['Vehicle_Id']}</td>";
                echo "<td>{$row['Date']}</td>";
                echo "<td>{$row['Service']}</td>";
                echo "<td>$" . number_format($row['Cost'], 2) . "</td>";
                echo "<td>{$row['Notes']}</td>";
                echo "<td><a class='delete-btn' href='?delete={$row['ID']}' onclick=\"return confirm('Delete this record?');\">Delete</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No records found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>

