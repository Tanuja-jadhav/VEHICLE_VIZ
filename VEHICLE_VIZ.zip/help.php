<?php // help.php ?>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Help - Car Management System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Contact support for Car Management System. Reach us by phone or email for help.">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body, html {
      height: 100%;
      font-family: Arial, sans-serif;
    }

    .background {
      background-color: #111;
      background-image: url('https://cdn.pixabay.com/photo/2024/07/13/07/40/cars-8891625_1280.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      height: 100vh;
      position: relative;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.6);
      color: white;
      padding: 40px;
      border-radius: 10px;
      text-align: center;
    }

    .overlay h1 {
      margin-bottom: 20px;
      font-size: 32px;
    }

    .overlay p {
      font-size: 18px;
      margin: 10px 0;
    }

    .overlay a {
      color: #00c3ff;
      text-decoration: none;
    }

    .overlay a:hover {
      text-decoration: underline;
    }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #00c3ff;
      color: black;
      border-radius: 5px;
      font-weight: bold;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }

    .back-link:hover {
      background-color: #00a3cc;
      color: white;
    }

    @media (max-width: 600px) {
      .overlay {
        padding: 20px;
      }
      .overlay h1 {
        font-size: 24px;
      }
      .overlay p {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>

  <div class="background">
    <div class="overlay">
      <h1>Need Help?</h1>
      <p>📞 Contact us at: <strong>+1-800-123-4567</strong></p>
      <p>📧 Email: <a href="mailto:support@carmanagement.com">support@carmanagement.com</a></p>
      
      <!-- Back to Home Page Link -->
      <a href="UI.php" class="back-link">⬅ Back to Home</a>
    </div>
  </div>

</body>
</html>
