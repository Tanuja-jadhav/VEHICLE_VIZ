<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}
?>

<?php
// Hide errors from users
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', 'errors.log');

// Database connection
$connection = mysqli_connect("localhost:3307", "root", "", "vehicle");
if (!$connection) {
    error_log("Connection failed: " . mysqli_connect_error());
    die("Something went wrong. Please try again later.");
}

// Handle form submit
if (isset($_POST['submit'])) {
    $employee_id = $_POST['employee_id'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $mobile_no = $_POST['mobile_no'];
    $join_date = $_POST['join_date'];
    $task = $_POST['task'];

    $query = "INSERT INTO employee (EMPLOYEE_ID, EMPLOYEE_NAME, DOB, ADDRESS, MOBILE_NO, JOIN_DATE, TASK)
              VALUES ('$employee_id', '$name', '$dob', '$address', '$mobile_no', '$join_date', '$task')";

    if (mysqli_query($connection, $query)) {
        $success = "✅ Employee added successfully!";
    } else {
        $error = "❌ Failed to add employee: " . mysqli_error($connection);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Panel - Add Employee</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 15px;
    }
    .sidebar a:hover {
      background-color: #495057;
    }
    .card {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

<div class="container-fluid">
 <body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 sidebar d-flex flex-column p-0">
        <h4 class="text-center mt-4">Admin Panel</h4>
        <a href="#">Dashboard</a>
        <a href="projectaddemployee.php">Manage Employee</a>
        <a href="vehiclerecord.php">Vehicle Record</a>
    
        <a href="projectvehiclemanage.php">Vehicle Management</a>
		 <a href="add_cars2.php">Add Vehicle</a>
		 <a href="projectadmincustomer.php">Customers</a>
		 <a href="projectadmincustomerrecord.php" class="block py-2 px-3 rounded hover:bg-gray-700 bg-gray-700">Customers Records</a>
        <a href="projectadminsold.php">Sold Vehicles</a>
		 <a href="projectadminloanrecord.php">Loan Application Record</a>
		
		 		 <a href="projectadminaddmaintainance.php">Maintainance</a>
				         <!-- Feedback Button -->
       
          <a href="admin_view_feedback.php">
             View Customer Feedback
          </a>
        

        <a href="adminlogout.php">Logout</a>
      </div>

    <!-- Main content -->
    <div class="col-md-10 p-5" >
      <div class="form-container">
        <div class="header" style="background-color:black;">
          <h3 class="text-primary" style="color:white">➕ Add New Employee</h3>
        </div>

        <?php if (isset($success)): ?>
          <div class="alert alert-success"><?php echo $success; ?></div>
        <?php elseif (isset($error)): ?>
          <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
          <div class="row mb-3">
            <div class="col">
              <label class="form-label">Employee ID</label>
              <input type="text" class="form-control" name="employee_id" required>
            </div>
            <div class="col">
              <label class="form-label">Employee Name</label>
              <input type="text" class="form-control" name="name" required>
            </div>
          </div>

          <div class="row mb-3">
            <div class="col">
              <label class="form-label">Date of Birth</label>
              <input type="date" class="form-control" name="dob" required>
            </div>
            <div class="col">
              <label class="form-label">Join Date</label>
              <input type="date" class="form-control" name="join_date" required>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea class="form-control" name="address" rows="2" required></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label">Mobile No</label>
            <input type="text" class="form-control" name="mobile_no" pattern="[0-9]{10}" maxlength="10" required>
          </div>

          <div class="mb-3">
            <label class="form-label">Task</label>
            <input type="text" class="form-control" name="task" required>
          </div>

          <button type="submit" name="submit" class="btn btn-success" style="background-color:black">✔ Add Employee</button>
          <a href="projectemployeerecord.php" class="btn btn-outline-primary ms-2">View All Employees →</a>
        </form>
      </div>
    </div>
  </div>
</div>

</body>
</html>

