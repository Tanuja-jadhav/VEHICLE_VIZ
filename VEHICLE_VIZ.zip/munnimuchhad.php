<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Attendance System</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>

   

body {
    font-family: Arial, sans-serif;
    background-color: #ffc0cb; /* Light orange background */
}

header {
    background-color: #ff9900; /* Orange background */
    color: #fff;
    padding: 10px;
    text-align: center;
}

.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: space-around;
}

nav li {
    margin-right: 20px;
}

nav a {
    color: #fff;
    text-decoration: none;
}

.attendance-container {
    display: flex;
    justify-content: space-around;
    padding: 20px;
}

.attendance-form {
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
    width: 400px;
}

.attendance-form h2 {
    color: #ff9900; /* Orange text */
}

.attendance-form label {
    display: block;
    margin-bottom: 10px;
}

.attendance-form input, .attendance-form select {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
}

.button-container {
    display: flex;
    justify-content: space-between;
}

.submit-btn {
    background-color: #ff9900; /* Orange background */
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}
</style>
    <header>
        <div class="header-container">
            <h1>Employee Attendance System</h1>
            <p>Welcome Mrunal More</p>
        </div>
        <nav>
            <ul>
                 <li><a href="#">HOME</a></li>                
                <li style ="display:inline;"><a href="#">ABOUT US</a></li>
                <li><a href="#">REPORTS</a>                     
                <li><a href="#">ADMINISTRATION</a></li>                  
                <li><a href="#">LOGOUT</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="attendance-container">
            <div class="attendance-form">
                <h2>EMPLOYEE ATTENDANCE</h2>
                <form>
                    <label for="employee">Select Employee:</label>
                    <select id="employee" name="employee">
                        <option value="1">Aman Kumar</option>
                        <option value="2">Ravi Kumar</option>
                        <option value="3">Pooja Sharma</option>
                       <option value="4">Priya Jhoshi</option>
                        <option value="5">Sakshi Yadav</option>
                        <option value="6">Riya Kumar</option>
                        <option value="7">Arjun Thakur </option>
                         <option value="8">Sanika Pawar</option>
                        <option value="9">Mrunal More</option>
                        <option value="10">Neha Raut</option>
                        <option value="11">Mohit Sinha</option>
                    </select>
                    <label for="attendance-date">Attendance Date:</label>
                    <input type="date" id="attendance-date" name="attendance-date" value="2019-09-11">
                    <label for="in-time">In Time:</label>
                    <input type="time" id="in-time" name="in-time">
                    <label for="out-time">Out Time:</label>
                    <input type="time" id="out-time" name="out-time">
                    <label for="description">Description:</label>
                    <input type="text" id="description" name="description">
                    <div class="button-container">
                        <button type="submit" class="submit-btn">Submit</button>
                        <button type="reset" class="reset-btn">Reset</button>
                    </div>
                </form>
            </div>
            <div class="advertisement">
                <h2>ADVERTISEMENT</h2>
                <div class="advertisement-content">
                    <p>Employee Attendance</p>
                    <p>WHO</p>
                    <img src="employee"
                    <p>WHEN</p>
                    <img src="alarm-clock.png" alt="Alarm Clock">
                </div>
                <p>&copy; Employee Attendance System</p>
            </div>
        </div>
    </main>
</body>
</html>