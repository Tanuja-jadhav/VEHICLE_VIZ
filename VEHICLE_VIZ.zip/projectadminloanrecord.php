<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to database
$connection = new mysqli("localhost:3307", "root", "", "vehicle");
if ($connection->connect_error) {
    die("Database connection failed: " . $connection->connect_error);
}

// Fetch all loan applications
$sql = "SELECT * FROM loan_applications ORDER BY application_date DESC";
$result = $connection->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Loan Application Record</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 15px;
    }
    .sidebar a:hover, .sidebar a.active {
      background-color: #495057;
    }
    .card {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .table thead th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 sidebar d-flex flex-column p-0">
        <h4 class="text-center mt-4">Admin Panel</h4>
        <a href="projectadmindash.php">Dashboard</a>
        <a href="projectaddemployee.php">Manage Employee</a>
        <a href="vehiclerecord.php">Vehicle Record</a>
        <a href="projectvehiclemanage.php">Vehicle Management</a>
        <a href="projectadmincustomer.php">Customers</a>
        <a href="projectadmincustomerrecord.php">Customer Records</a>
        <a href="projectadminsold.php">Sold Vehicles</a>
        <a href="projectadminloanrecord.php" class="active">Loan Application Record</a>
        <a href="adminlogin.php">Logout</a>
      </div>

      <!-- Main Content -->
      <div class="col-md-10 p-4">
        <h2 class="mb-4">Loan Application Records</h2>
        <div class="card shadow">
          <div class="card-body">
            <?php if ($result->num_rows > 0): ?>
              <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                  <thead class="table-dark">
                    <tr>
                      <th>ID</th>
                      <th>Full Name</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Loan Amount (₹)</th>
                      <th>Loan Purpose</th>
                      <th>Application Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($row = $result->fetch_assoc()): ?>
                      <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td><?= number_format($row['loan_amount'], 2) ?></td>
                        <td><?= htmlspecialchars($row['loan_purpose']) ?></td>
                        <td><?= $row['application_date'] ?></td>
                      </tr>
                    <?php endwhile; ?>
                  </tbody>
                </table>
              </div>
            <?php else: ?>
              <div class="alert alert-info text-center">No loan applications found.</div>
            <?php endif; ?>
          </div>
        </div>

        <div class="text-center mt-3">
          <a href="VIZ_loan_application.php" class="btn btn-primary">Back to Application Form</a>
        </div>
      </div>
    </div>
  </div>

<?php $connection->close(); ?>
</body>
</html>

