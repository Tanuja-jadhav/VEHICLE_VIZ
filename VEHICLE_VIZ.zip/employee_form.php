<?php
// employee_form.php

// Simple hardcoded login validation (optional)
$valid_username = "admin";
$valid_password = "admin123";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  if ($username !== $valid_username || $password !== $valid_password) {
    echo "<script>alert('Invalid Login'); window.location.href='login.php';</script>";
    exit;
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Employee Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-4">
    <h2 class="text-center mb-4">Employee Registration Form</h2>
    <form class="card shadow p-4" method="POST">
      <div class="row mb-3">
        <div class="col">
          <label class="form-label">First Name</label>
          <input type="text" class="form-control" name="first_name" required>
        </div>
        <div class="col">
          <label class="form-label">Last Name</label>
          <input type="text" class="form-control" name="last_name" required>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" class="form-control" name="email" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Phone</label>
        <input type="tel" class="form-control" name="phone" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Address</label>
        <textarea class="form-control" name="address" rows="2" required></textarea>
      </div>

      <div class="mb-3">
        <label class="form-label">Date of Birth</label>
        <input type="date" class="form-control" name="dob" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Gender</label><br>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="gender" value="Male" required>
          <label class="form-check-label">Male</label>
        </div>
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="gender" value="Female">
          <label class="form-check-label">Female</label>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Department</label>
        <input type="text" class="form-control" name="department" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Position</label>
        <input type="text" class="form-control" name="position" required>
      </div>

      <button type="submit" class="btn btn-success w-100">Submit</button>
    </form>
  </div>
</body>
</html>
