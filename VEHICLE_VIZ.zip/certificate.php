<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: user_login.php");
    exit;
}
?>


<?php
// certificate.php

$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "details";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$booking = null;
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM car_book WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $booking = $result->fetch_assoc();
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Booking Certificate</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background: #444444;
            margin: 0;
            padding: 40px;
            color: #eee;
        }

        .certificate {
            max-width: 800px;
            margin: 0 auto;
            padding: 40px;
            background: #f9f9f9;
            border: 10px solid #2c3e50;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.3);
            text-align: center;
            color: #222;
        }

        .certificate h1 {
            font-size: 36px;
            margin-bottom: 10px;
            color: #2c3e50;
        }

        .certificate h2 {
            font-size: 22px;
            margin: 20px 0;
        }

        .info {
            text-align: left;
            margin-top: 30px;
            font-size: 16px;
            line-height: 1.8;
            color: #333;
        }

        .info strong {
            color: #111;
        }

        .footer {
            margin-top: 40px;
            font-style: italic;
            color: #666;
        }

        .print-btn {
            margin: 30px auto 10px;
            display: inline-block;
            padding: 12px 25px;
            font-size: 16px;
            background: #3498db;
            color: #fff;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .print-btn:hover {
            background: #2980b9;
        }

        .back-btn {
            display: block;
            width: fit-content;
            margin: 30px auto 0;
            font-size: 16px;
            text-decoration: none;
            color: #3498db;
            background: #fff;
            border: 2px solid #3498db;
            padding: 10px 20px;
            border-radius: 6px;
            transition: background 0.3s ease, color 0.3s ease;
            text-align: center;
        }

        .back-btn:hover {
            background: #3498db;
            color: #fff;
        }
    </style>
</head>
<body>

<?php if ($booking): ?>
    <div class="certificate">
        <h1>Booking Certificate</h1>
        <h2>This certifies that</h2>
        <h2><strong><?= htmlspecialchars($booking['name']) ?></strong></h2>
        <p>has successfully booked a vehicle with us.</p>

        <div class="info">
            <p><strong>Email:</strong> <?= htmlspecialchars($booking['email']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($booking['phone']) ?></p>
            <p><strong>Address:</strong> <?= nl2br(htmlspecialchars($booking['address'])) ?></p>
            <p><strong>Pickup Date:</strong> <?= htmlspecialchars($booking['pickup_date']) ?></p>
            <p><strong>Payment Method:</strong> <?= htmlspecialchars($booking['payment_method']) ?></p>
            <?php if (!empty($booking['notes'])): ?>
                <p><strong>Notes:</strong> <?= nl2br(htmlspecialchars($booking['notes'])) ?></p>
            <?php endif; ?>
        </div>

        <div class="footer">
            Issued on <?= date("F d, Y") ?> by Vehicle Management System.
        </div>

        <button class="print-btn" onclick="window.print()">Download / Print</button>
	
    </div>

    <!-- Back button outside the certificate -->
    <a href="javascript:history.back()" class="back-btn">← Back</a>

<?php else: ?>
    <p style="text-align:center; color: #eee;">Booking not found.</p>
<?php endif; ?>

</body>
</html>
<!-- Back Button -->
    <a href="carlisting.php" class="back-btn" role="button">← Back to Car listing</a>

    <!-- Feedback Button -->
    <a href="feddback.php" class="feedback-btn" role="button">💬 Give Feedback</a>
</div>

<style>
    .feedback-btn {
        background: #ff9800; /* orange */
        color: #fff;
        display: block;
        margin-top: 15px;
        padding: 14px;
        font-size: 16px;
        border-radius: 8px;
        text-align: center;
        text-decoration: none;
        transition: background 0.3s;
    }
    .feedback-btn:hover {
        background: #e68900;
    }
</style>
