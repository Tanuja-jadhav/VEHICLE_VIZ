<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['email'])) {
    header("Location: VIZ_loan_permission1.php");
    exit;
}

$error = '';

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Dummy login credentials
    if ($email === "tanujajadhav012@gmail.com" && $password === "1234") {
        $_SESSION['email'] = $email;
        session_regenerate_id(true); // Prevent session fixation
        header("Location: VIZ_loan_permission1.php");
        exit;
    } else {
        $error = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Poppins', sans-serif;
    }

    body {
      background: linear-gradient(to right, #36d1dc, #5b86e5);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .login-container {
      background: #fff;
      padding: 2.5rem 3rem;
      border-radius: 12px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 400px;
      animation: fadeIn 0.8s ease-in;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .login-container h2 {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #333;
    }

    .form-group {
      margin-bottom: 1rem;
    }

    .form-group label {
      font-size: 0.9rem;
      color: #555;
      display: block;
      margin-bottom: 0.3rem;
    }

    .form-group input {
      width: 100%;
      padding: 0.7rem 1rem;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus {
      border-color: #5b86e5;
      outline: none;
      box-shadow: 0 0 5px rgba(91, 134, 229, 0.5);
    }

    .login-btn {
      width: 100%;
      padding: 0.9rem;
      background-color: #5b86e5;
      color: white;
      font-size: 1rem;
      font-weight: 600;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .login-btn:hover {
      background-color: #4a73cf;
    }

    .extra-link {
      text-align: center;
      margin-top: 1rem;
      font-size: 0.9rem;
      color: #555;
    }

    .extra-link a {
      color: #5b86e5;
      text-decoration: none;
      font-weight: 600;
    }

    .extra-link a:hover {
      text-decoration: underline;
    }

    .btn-group {
      display: flex;
      justify-content: space-between;
      margin-top: 1.5rem;
    }

    .btn-back,
    .btn-next {
      width: 48%;
      padding: 0.8rem;
      border-radius: 8px;
      font-weight: 600;
      font-size: 0.95rem;
      cursor: pointer;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }

    .btn-back {
      background-color: #999;
      color: white;
    }

    .btn-back:hover {
      background-color: #777;
    }

    .btn-next {
      background-color: #5b86e5;
      color: white;
    }

    .btn-next:hover {
      background-color: #4a73cf;
    }

    .error {
      color: red;
      text-align: center;
      margin-bottom: 1rem;
    }

    @media (max-width: 500px) {
      .login-container {
        padding: 2rem;
      }
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Welcome Back</h2>

    <?php if ($error): ?>
      <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" placeholder="you@example.com" required />
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" placeholder="••••••••" required />
      </div>
      <button type="submit" class="login-btn">Login</button>
    </form>

    <p class="extra-link">Don't have an account? <a href="VIZ_SignUp.php">Sign Up</a></p>
    <p class="extra-link">Forgot password? <a href="VIZ_password_recovery.php">Click here</a></p>

    <!-- Back and Next buttons -->
    <div class="btn-group">
      <a href="UI.php" class="btn-back">Back</a>
      <a href="VIZ_loan_permission1.php" class="btn-next">Next</a>
    </div>
  </div>
</body>
</html>
