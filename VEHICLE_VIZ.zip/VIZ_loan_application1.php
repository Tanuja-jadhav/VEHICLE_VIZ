

<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: VIZ_login1.php");
    exit;
}
?>



<?php

// Show errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Connect to database
$mysqli = new mysqli("localhost:3307", "root", "", "details");

// Check connection
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve and sanitize POST data
    $user_id = intval($_POST['user_id']);
    $car_id = intval($_POST['car_id']);
    $loan_amount = floatval($_POST['loan_amount']);
    $loan_term = intval($_POST['loan_term']);
    $interest_rate = floatval($_POST['interest_rate']);

    // Prepare the insert statement
    $stmt = $mysqli->prepare("INSERT INTO car_loans (user_id, car_id, loan_amount, loan_term, interest_rate) VALUES (?, ?, ?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("iiddi", $user_id, $car_id, $loan_amount, $loan_term, $interest_rate);
        if ($stmt->execute()) {
            // Redirect after successful insert
            header("Location: VIZ_logout1.php");
            exit();
        } else {
            $message = '<div class="alert alert-danger">Execute failed: ' . $stmt->error . '</div>';
        }
        $stmt->close();
    } else {
        $message = '<div class="alert alert-danger">Prepare failed: ' . $mysqli->error . '</div>';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Car Loan Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="row justify-content-end">
        <div class="col-md-12 text-end">
            <a href="logout.php" class="btn btn-outline-danger mb-3">Logout</a>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0 text-center">Car Loan Application</h4>
                </div>
                <div class="card-body">
                    <?php echo $message; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">User ID</label>
                            <input type="number" name="user_id" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Car ID</label>
                            <input type="number" name="car_id" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Loan Amount</label>
                            <input type="number" name="loan_amount" step="0.01" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Loan Term (Months)</label>
                            <input type="number" name="loan_term" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Interest Rate (%)</label>
                            <input type="number" name="interest_rate" step="0.01" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Submit Loan Request</button>
                    </form>
                </div>
            </div>
            <div class="text-center mt-3 text-muted">
                &copy; <?php echo date('Y'); ?> Car Management System
            </div>
        </div>
    </div>
</div>
</body>
</html>

