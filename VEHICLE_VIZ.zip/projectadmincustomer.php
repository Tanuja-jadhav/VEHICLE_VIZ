<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}
?>

<?php
$connection = mysqli_connect("localhost:3307", "root", "", "vehicle");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $vehicle = $_POST['vehicle'];
    $purchase_date = $_POST['purchase_date'];

    $insert_query = "INSERT INTO customer (NAME, ADDRESS, MOBILE_NO, EMAIL, VEHICLE_PURCHASED, PURCHASE_DATE) 
                     VALUES ('$name', '$address', '$mobile', '$email', '$vehicle', '$purchase_date')";
    mysqli_query($connection, $insert_query);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($connection, "DELETE FROM customer WHERE CUSTOMER_ID = '$id'");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$result = mysqli_query($connection, "SELECT * FROM customer");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Customers - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 15px;
    }
    .sidebar a:hover {
      background-color: #495057;
    }
    .card {
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
  </style>
<body class="bg-gray-100 text-gray-800 min-h-screen">

<div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 sidebar d-flex flex-column p-0">
        <h4 class="text-center mt-4">Admin Panel</h4>
        <a href="#">Dashboard</a>
        <a href="projectaddemployee.php">Manage Employee</a>
        <a href="vehiclerecord.php">Vehicle Record</a>
    
        <a href="projectvehiclemanage.php">Vehicle Management</a>
		 <a href="add_cars2.php">Add Vehicle</a>
		 <a href="projectadmincustomer.php">Customers</a>
		 <a href="projectadmincustomerrecord.php" class="block py-2 px-3 rounded hover:bg-gray-700 bg-gray-700">Customers Records</a>
        <a href="projectadminsold.php">Sold Vehicles</a>
		 <a href="projectadminloanrecord.php">Loan Application Record</a>
		
		 		 <a href="projectadminaddmaintainance.php">Maintainance</a>
				         <!-- Feedback Button -->
       
          <a href="admin_view_feedback.php">
             View Customer Feedback
          </a>
        

        <a href="adminlogout.php">Logout</a>
      </div>

    <!-- Main content -->
    <div class="flex-1 p-10">
        <div class="bg-white shadow rounded-lg p-6 mb-10">
            <h2 class="text-2xl font-bold mb-4">➕ Add Customer</h2>
            <form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" name="name" placeholder="Customer Name" required class="p-2 border border-gray-300 rounded">
                <input type="text" name="address" placeholder="Address" class="p-2 border border-gray-300 rounded">
                <input type="text" name="mobile" placeholder="Mobile Number" required class="p-2 border border-gray-300 rounded">
                <input type="email" name="email" placeholder="Email" class="p-2 border border-gray-300 rounded">
                <input type="text" name="vehicle" placeholder="Vehicle Purchased" required class="p-2 border border-gray-300 rounded">
                <input type="date" name="purchase_date" required class="p-2 border border-gray-300 rounded">
                <button type="submit" name="submit" class="col-span-1 md:col-span-2 bg-black text-white py-2 px-4 rounded hover:bg-gray-800">
                    Add Customer
                </button>
            </form>
        </div>

       <!-- <div class="bg-white shadow rounded-lg p-6">
            <h2 class="text-xl font-bold mb-4">📋 Customer Records</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full table-auto text-sm text-left">
                    <thead class="bg-gray-200">
                        <tr>
                            <th class="px-4 py-2">ID</th>
                            <th class="px-4 py-2">Name</th>
                            <th class="px-4 py-2">Address</th>
                            <th class="px-4 py-2">Mobile</th>
                            <th class="px-4 py-2">Email</th>
                            <th class="px-4 py-2">Vehicle</th>
                            <th class="px-4 py-2">Purchase Date</th>
                            <th class="px-4 py-2">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-300">
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr class="hover:bg-gray-100">
                                <td class="px-4 py-2"><?php echo $row['CUSTOMER_ID']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['NAME']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['ADDRESS']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['MOBILE_NO']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['EMAIL']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['VEHICLE_PURCHASED']; ?></td>
                                <td class="px-4 py-2"><?php echo $row['PURCHASE_DATE']; ?></td>
                                <td class="px-4 py-2">
                                    <a href="?delete=<?php echo $row['CUSTOMER_ID']; ?>" onclick="return confirm('Are you sure?')" class="text-red-600 hover:underline">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>-->
    </div>
</div>

</body>
</html>
