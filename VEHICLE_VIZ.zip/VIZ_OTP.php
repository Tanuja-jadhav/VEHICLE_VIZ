

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Verify OTP</title>
  <style>
    body {
      background: #f1f8e9;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      background: white;
      padding: 2rem;
      border-radius: 12px;
      width: 350px;
      box-shadow: 0 0 20px rgba(0,0,0,0.1);
      text-align: center;
    }
    input, button {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
    }
    button {
      background-color: #4caf50;
      color: white;
      font-weight: bold;
      border: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>OTP Verification</h2>
    <p>Enter the 6-digit OTP sent to your email</p>
    <form onsubmit="verifyOtp(event)">
      <input type="text" id="otpInput" maxlength="6" placeholder="Enter OTP" required />
      <button type="submit">Verify</button>
    </form>
    <p id="error" style="color:red;"></p>
  </div>

  <script>
    function verifyOtp(e) {
      e.preventDefault();
      const enteredOtp = document.getElementById('otpInput').value;
      const storedOtp = localStorage.getItem('otp');

      if (enteredOtp === storedOtp) {
        window.location.href = "VIZ_reset_passward.php";
      } else {
        document.getElementById('error').innerText = "Invalid OTP. Try again.";
      }
    }
  </script>
  </body>
  </html>