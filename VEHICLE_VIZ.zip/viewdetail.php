<?php
// Car listing array
$cars = [
    "Honda Civic" => [
        "image" => "https://automobiles.honda.com/-/media/Honda-Automobiles/Vehicles/Family-Pages/Civic-Family/Civic-Hatchback/Hybrid/2026/MY26_Civic_Family_Card_Jelly_Hybrid2x.png?sc_lang=en",
        "description" => "Sedan with fuel-efficient engine, modern design.",
        "price" => "₹20 Lakhs"
    ],
    "Toyota Fortuner" => [
        "image" => "https://imgd.aeplcdn.com/370x208/n/qv5knta_1500713.jpg?q=80",
        "description" => "Powerful SUV with off-road capability.",
        "price" => "₹35 Lakhs"
    ],
    "Ferrari" => [
        "image" => "https://stimg.cardekho.com/images/car-images/large/Ferrari/Ferrari-488-GTB/Nero-Pastello.jpg?impolicy=resize&imwidth=420",
        "description" => "Luxury sports car with V8 engine.",
        "price" => "₹4 Crore"
    ]
];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Listing</title>
    <style>
        body { font-family: Arial; text-align: center; margin: 0; padding: 20px; }
        .car-list { display: flex; justify-content: center; flex-wrap: wrap; gap: 20px; }
        .car { border: 1px solid #ccc; border-radius: 8px; width: 250px; padding: 10px; }
        .car img { width: 100%; height: 150px; object-fit: cover; border-radius: 6px; }
        button { margin-top: 10px; padding: 6px 12px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Car Listings</h1>

    <div class="car-list">
        <?php foreach ($cars as $name => $info): ?>
            <div class="car">
                <img src="<?= $info['image'] ?>" alt="<?= $name ?>">
                <h3><?= $name ?></h3>
                <a href="book.php?name=<?= urlencode($name) ?>&image=<?= urlencode($info['image']) ?>&description=<?= urlencode($info['description']) ?>&price=<?= urlencode($info['price']) ?>">
                    <button>View Details</button>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
