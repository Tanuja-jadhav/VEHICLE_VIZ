<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: user_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #e0f7fa, #e1bee7);
      margin: 0;
      padding: 20px;
    }

    .contact-container {
      max-width: 800px;
      margin: auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    h1 {
      color: #333;
    }

    .member {
      border-bottom: 1px solid #ccc;
      padding: 15px 0;
    }

    .member:last-child {
      border-bottom: none;
    }

    .member h3 {
      margin: 0;
      color: #007BFF;
    }

    .contact-info {
      margin-top: 5px;
      line-height: 1.6;
    }

    .contact-info a {
      color: #333;
      text-decoration: none;
    }

    .contact-info a:hover {
      text-decoration: underline;
    }

    .back-link {
      display: inline-block;
      margin-top: 30px;
      padding: 10px 20px;
      background-color: #007BFF;
      color: #fff;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .back-link:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<div class="contact-container">
  <h1>Contact Us</h1>

  <?php
    $members = [
      ["name" => "Suhani Sahane", "phone" => "+9373781556", "email" => "suhanisahane123@gmail.com"],
      ["name" => "Tanuja Jadhav", "phone" => "+9322671089", "email" => "tanujajadhav012@gmail.com"],
      ["name" => "Nikita Kadam", "phone" => "+9881825895", "email" => "kadamnikita953@gmail.com"],
      ["name" => "Dnyaneshwari Shelake", "phone" => "+8767948745", "email" => "shelkednyaneshwari478@gmail.com"],
      ["name" => "Pranjali Thorat", "phone" => "+9309013916", "email" => "pranjalithorat22@gmail.com"]
    ];

    foreach ($members as $member) {
      echo '<div class="member">';
      echo '<h3>' . htmlspecialchars($member['name']) . '</h3>';
      echo '<div class="contact-info">';
      echo '📞 <a href="tel:' . htmlspecialchars($member['phone']) . '">' . htmlspecialchars($member['phone']) . '</a><br>';
      echo '📧 <a href="mailto:' . htmlspecialchars($member['email']) . '">' . htmlspecialchars($member['email']) . '</a>';
      echo '</div></div>';
    }
  ?>

  <!-- Back to Home Link -->
  <a href="UI.php" class="back-link">⬅ Back to Home</a>

</div>

</body>
</html>
