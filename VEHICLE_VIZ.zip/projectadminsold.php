<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}
?>

<?php
$connection = mysqli_connect("localhost:3307", "root", "", "car_showroom");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Query for sold vehicles
$query = "SELECT * FROM SOLD_VEHICLE WHERE STATUS = 'Sold'";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sold Vehicles - Admin Panel</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .sidebar {
      height: 100vh;
      background-color: #343a40;
      color: white;
    }
    .sidebar a {
      color: white;
      text-decoration: none;
      display: block;
      padding: 15px;
    }
    .sidebar a:hover {
      background-color: #495057;
    }
    .card-img-top {
      height: 200px;
      object-fit: cover;
    }
  </style>
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- Sidebar -->
      <div class="col-md-2 sidebar d-flex flex-column p-0">
        <h4 class="text-center mt-4">Admin Panel</h4>
        <a href="projectadmindash.php">Dashboard</a>
        <a href="projectaddemployee.php">Manage Employee</a>
        <a href="vehiclerecord.php">Vehicle Record</a>
		  <a href="add_cars2.php">🚗 Add Vehicle</a>
        <a href="projectvehiclemanage.php">Vehicle Management</a>
        <a href="projectadmincustomer.php">Customers</a>
        <a href="soldvehicles.php" class="bg-primary text-white">Sold Vehicles</a>
        <a href="#">Logout</a>
      </div>

      <!-- Main Content -->
      <div class="col-md-10 p-4">
        <h2 class="mb-4">Sold Vehicles</h2>
        <div class="row">
          <?php while ($row = mysqli_fetch_assoc($result)) : ?>
            <div class="col-md-4 mb-4">
              <div class="card h-100 shadow-sm">
                <img src="<?php echo htmlspecialchars($row['IMAGE_PATH']); ?>" class="card-img-top" alt="Vehicle Image">
                <div class="card-body">
                  <h5 class="card-title"><?php echo htmlspecialchars($row['NAME']); ?></h5>
                  <p class="card-text"><strong>Brand:</strong> <?php echo htmlspecialchars($row['BRAND']); ?></p>
                  <p class="card-text"><strong>Price:</strong> ₹<?php echo number_format($row['PRICE']); ?></p>
                  <span class="badge bg-success"><?php echo htmlspecialchars($row['STATUS']); ?></span>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>