<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>VK AUTO Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-image: url('https://images.unsplash.com/photo-1612544448445-b8232cff3b6c?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D');
      background-size: cover;
      background-position: center center;
      background-repeat: no-repeat;
      background-attachment: fixed;
      color: white;
    }

    html {
      scroll-behavior: smooth;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: rgba(0, 0, 0, 0.8);
      padding: 15px 30px;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .logo {
      font-size: 24px;
      font-weight: bold;
      letter-spacing: 1px;
    }

    .auth-buttons button {
      background: #00a8ff;
      border: none;
      color: white;
      padding: 10px 18px;
      margin-left: 12px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 15px;
      transition: background 0.3s;
    }

    .auth-buttons button:hover {
      background: #007bff;
    }

    .main-content {
      text-align: center;
      padding: 80px 20px;
      background-color: rgba(0, 0, 0, 0.5);
      min-height: 100vh;
    }

    .main-content h1 {
      font-size: 64px;
      margin-bottom: 10px;
      animation: fadeInDown 1s ease-out;
    }

    .main-content h2 {
      font-size: 36px;
      color: #00a8ff;
      animation: fadeInUp 1s ease-out;
    }

    @keyframes fadeInDown {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    footer {
      text-align: center;
      padding: 20px;
      background: rgba(0, 0, 0, 0.7);
      font-size: 14px;
      color: #ccc;
    }

    /* Optional dashboard cards */
    .dashboard-cards {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 40px;
    }

    .card {
      background: white;
      color: black;
      padding: 20px;
      border-radius: 8px;
      width: 220px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
      text-align: center;
    }

    .card h3 {
      margin: 0;
      font-size: 18px;
    }

    .card p {
      font-size: 24px;
      margin-top: 10px;
      color: #00a8ff;
    }

    @media screen and (max-width: 768px) {
      .main-content h1 {
        font-size: 42px;
      }
      .main-content h2 {
        font-size: 24px;
      }
      .dashboard-cards {
        flex-direction: column;
        align-items: center;
      }
    }
  </style>
</head>
<body>

  <!-- Navigation -->
  <div class="navbar">
    <div class="logo">VK AUTO</div>
    <div class="auth-buttons">
      <button onclick="location.href='adminlogin.php'">Admin Login</button>
      <button onclick="location.href='user_login.php'">User Login</button>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <h1>VK AUTO</h1>
    <h2>Vehicle Management System</h2>

    <!-- Optional Cards -->
    <!-- 
    <div class="dashboard-cards">
      <div class="card">
        <h3>Total Vehicles</h3>
        <p>120</p>
      </div>
      <div class="card">
        <h3>Active Rentals</h3>
        <p>45</p>
      </div>
      <div class="card">
        <h3>Under Maintenance</h3>
        <p>12</p>
      </div>
      <div class="card">
        <h3>Available Drivers</h3>
        <p>30</p>
      </div>
    </div>
    -->
  </div>

  <!-- Footer -->
  <footer>
    &copy; 2025 VK AUTO | All rights reserved
  </footer>

</body>
</html>
