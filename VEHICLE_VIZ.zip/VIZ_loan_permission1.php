<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: VIZ_login1.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Bank Loan Permission</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
      font-family: 'Montserrat', sans-serif;
    }

    body {
      height: 100vh;
      background: linear-gradient(120deg, #4b6cb7, #182848);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1rem;
      color: #f0f4f8;
    }

    .container {
      background: rgba(255,255,255,0.12);
      backdrop-filter: blur(12px);
      border-radius: 16px;
      padding: 2.5rem 3rem;
      max-width: 450px;
      width: 100%;
      text-align: center;
      box-shadow: 0 14px 40px rgba(0,0,0,0.5);
      animation: fadeIn 0.7s ease forwards;
    }

    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(25px);}
      to {opacity: 1; transform: translateY(0);}
    }

    h1 {
      font-weight: 700;
      font-size: 2rem;
      margin-bottom: 1rem;
      text-shadow: 0 2px 6px rgba(0,0,0,0.4);
    }

    p {
      font-size: 1.1rem;
      margin-bottom: 2rem;
      line-height: 1.5;
      color: #d1d7e0;
      text-shadow: 0 1px 3px rgba(0,0,0,0.3);
    }

    .btn-group {
      display: flex;
      justify-content: center;
      gap: 1.5rem;
    }

    button {
      padding: 0.75rem 3rem;
      font-size: 1.1rem;
      font-weight: 600;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      box-shadow: 0 6px 15px rgba(0,0,0,0.25);
      transition: background-color 0.3s ease, transform 0.2s ease;
      user-select: none;
      color: white;
    }

    button:focus {
      outline: 3px solid #fff;
      outline-offset: 3px;
    }

    .btn-yes {
      background-color: #3ac569;
    }

    .btn-yes:hover {
      background-color: #2d9c4f;
      transform: scale(1.05);
    }

    .btn-no {
      background-color: #f44336;
    }

    .btn-no:hover {
      background-color: #b83227;
      transform: scale(1.05);
    }
  </style>
</head>
<body>

  <main class="container" role="main" aria-label="Bank Loan Permission Request">
    <h1>Permission to Take Loan</h1>
    <p>
      Do you give us permission to process your loan application with the bank? 
      This includes verifying your financial details securely to offer you the best loan options.
    </p>

    <div class="btn-group" role="group" aria-label="Loan permission options">
      <button class="btn-yes" type="button" id="yesBtn">Yes, I Consent</button>
      <button class="btn-no" type="button" id="noBtn">No, I Decline</button>
    </div>
  </main>

  <script>
    document.getElementById('yesBtn').addEventListener('click', () => {
     // alert('Thank you! Your permission has been recorded.');
	  window.location.href="VIZ_loan_application1.php";
      // Insert your backend or redirect logic here
    });

    document.getElementById('noBtn').addEventListener('click', () => {
     // alert('You have declined permission to take the loan.');
      // Insert your alternative flow logic here
	  window.location.href="#";
    });
  </script>
  
</body>
</html>
