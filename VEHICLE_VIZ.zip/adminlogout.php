


<?php
session_start();
$_SESSION = [];
session_destroy();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Logged Out</title>
  <style>
    body {
      font-family: "Segoe UI", Tahoma, sans-serif;
      background: linear-gradient(135deg, #667eea, #764ba2);
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .logout-box {
      background: white;
      padding: 40px;
      border-radius: 12px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    .logout-box h1 {
      color: #764ba2;
    }
    .logout-box a {
      display: inline-block;
      margin-top: 20px;
      padding: 12px 25px;
      background-color: #667eea;
      color: white;
      text-decoration: none;
      border-radius: 6px;
    }
    .logout-box a:hover {
      background-color: #5567d2;
    }
  </style>
</head>
<body>
  <div class="logout-box">
    <h1>You’ve been logged out</h1>
    <p>Thank you! Click below to log in again.</p>
    <a href="adminlogin.php">Back to Login</a>
  </div>
</body>
</html>
