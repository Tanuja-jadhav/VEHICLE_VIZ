<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = ""; // Change if needed
$dbname = "details";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";
$errorMsg = "";

// Make sure uploads folder exists
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $name = trim($_POST["name"]);
    $year = intval($_POST["year"]);
    $description = trim($_POST["description"]);
    $details = trim($_POST["details"]);

    // Validate required fields
    if (!$name || !$year || !$description || !$details) {
        $errorMsg = "❗ Please fill in all the fields.";
    } elseif (!isset($_FILES["image"]) || $_FILES["image"]["error"] !== UPLOAD_ERR_OK) {
        $errorMsg = "❗ Please upload an image.";
    } else {
        // Validate and process the image upload
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
        $fileTmpPath = $_FILES["image"]["tmp_name"];
        $fileName = basename($_FILES["image"]["name"]);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (!in_array($fileExt, $allowedTypes)) {
            $errorMsg = "❌ Only JPG, JPEG, PNG, and GIF files are allowed.";
        } else {
            // Generate a unique file name to prevent overwriting
            $newFileName = time() . "_" . preg_replace("/[^a-zA-Z0-9_-]/", "_", pathinfo($fileName, PATHINFO_FILENAME)) . "." . $fileExt;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // Insert data into database
                $sql = "INSERT INTO car_details (NAME, YEAR, IMAGE, DESCRIPTION, DETAILS) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sisss", $name, $year, $destPath, $description, $details);
                    if ($stmt->execute()) {
                        $successMsg = "✅ Car added successfully!";
                    } else {
                        $errorMsg = "❌ Database error: " . $stmt->error;
                        // Delete the uploaded file since DB insert failed
                        if (file_exists($destPath)) unlink($destPath);
                    }
                    $stmt->close();
                } else {
                    $errorMsg = "❌ Database prepare error: " . $conn->error;
                    if (file_exists($destPath)) unlink($destPath);
                }
            } else {
                $errorMsg = "❌ Failed to move uploaded file.";
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Add Car with Image Upload</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f4f6f8;
        margin: 0; padding: 0;
        text-align: center;
    }
    h1 {
        background-color: #2c3e50;
        color: white;
        padding: 20px 0;
        margin-bottom: 30px;
    }
    .form-container {
        background: #fff;
        width: 400px;
        margin: 0 auto 40px;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 6px 12px rgba(0,0,0,0.1);
        text-align: left;
    }
    form label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }
    form input[type="text"],
    form input[type="number"],
    form textarea,
    form input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
        box-sizing: border-box;
    }
    form button {
        width: 100%;
        padding: 12px;
        background: #3498db;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s;
    }
    form button:hover {
        background: #2980b9;
    }
    .success {
        color: green;
        font-weight: bold;
        margin-bottom: 20px;
    }
    .error {
        color: red;
        font-weight: bold;
        margin-bottom: 20px;
    }
</style>
<script>
function validateForm() {
    const form = document.forms["carForm"];
    if (!form.name.value.trim() ||
        !form.year.value.trim() ||
        !form.image.value.trim() ||
        !form.description.value.trim() ||
        !form.details.value.trim()) {
        alert("All fields are required.");
        return false;
    }
    return true;
}
</script>
</head>
<body>

<h1>Add New Car</h1>

<div class="form-container">
    <?php if ($successMsg): ?>
        <p class="success"><?= htmlspecialchars($successMsg) ?></p>
    <?php endif; ?>
    <?php if ($errorMsg): ?>
        <p class="error"><?= htmlspecialchars($errorMsg) ?></p>
    <?php endif; ?>

    <form name="carForm" method="POST" enctype="multipart/form-data" onsubmit="return validateForm();">
        <label>Car Name:</label>
        <input type="text" name="name" required />

        <label>Year:</label>
        <input type="number" name="year" min="1886" max="2099" required />

        <label>Upload Image:</label>
        <input type="file" name="image" accept="image/*" required />

        <label>Description:</label>
        <textarea name="description" rows="3" required></textarea>

        <label>Details:</label>
        <textarea name="details" rows="4" required></textarea>

        <button type="submit">Add Car</button>
    </form>
</div>

</body>
</html>
