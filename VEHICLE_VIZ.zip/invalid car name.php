<?php
// Initialize variables
$name = $email = $phone = $car = $date = $location = "";
$showCertificate = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $email = htmlspecialchars($_POST["email"]);
    $phone = htmlspecialchars($_POST["phone"]);
    $car = htmlspecialchars($_POST["car"]);
    $date = htmlspecialchars($_POST["date"]);
    $location = htmlspecialchars($_POST["location"]);
    $showCertificate = true;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Book Now - Car Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f3;
            padding: 40px;
        }

        .form-container, .certificate-container {
            background: white;
            width: 500px;
            margin: auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #ccc;
            display: none;
        }

        .form-container.active,
        .certificate-container.active {
            display: block;
        }

        h2 {
            text-align: center;
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #aaa;
            border-radius: 5px;
        }

        button {
            margin-top: 20px;
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
        }

        .certificate {
            text-align: center;
            line-height: 1.6;
        }

        .certificate h3 {
            margin-bottom: 10px;
        }

        .print-btn {
            background-color: green;
            margin-top: 20px;
        }

        .certificate strong {
            display: block;
            margin: 5px 0;
        }
    </style>
</head>
<body>

<!-- Booking Form -->
<div class="form-container <?php echo $showCertificate ? '' : 'active'; ?>" id="bookingForm">
    <h2>Car Booking Form</h2>
    <form method="POST" action="">
        <label>Full Name</label>
        <input type="text" name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Phone Number</label>
        <input type="tel" name="phone" required pattern="[0-9]{10}" placeholder="10-digit number">

        <label>Select Car</label>
        <select name="car" required>
            <option value="">--Select Car--</option>
            <option value="Honda Civic">Honda Civic</option>
            <option value="Toyota Fortuner">Toyota Fortuner</option>
            <option value="Mahindra Scorpio">Mahindra Scorpio</option>
            <option value="Hyundai Creta">Hyundai Creta</option>
            <option value="Tata Nexon">Tata Nexon</option>
            <option value="Ferrari">Ferrari</option>
            <option value="Thar">Thar</option>
            <option value="Audi">Audi</option>
            <option value="Range Rover">Range Rover</option>
            <option value="Rolls Royce">Rolls Royce</option>
        </select>

        <label>Booking Date</label>
        <input type="date" name="date" required>

        <label>Pickup Location</label>
        <input type="text" name="location" required>

        <button type="submit">Book Now</button>
    </form>
</div>

<!-- Certificate Display -->
<div class="certificate-container <?php echo $showCertificate ? 'active' : ''; ?>" id="certificate">
    <div class="certificate">
        <h2>🚗 Car Booking Certificate</h2>
        <h3>Car Management System</h3>
        <strong>Name:</strong> <span><?php echo $name; ?></span>
        <strong>Email:</strong> <span><?php echo $email; ?></span>
        <strong>Phone:</strong> <span><?php echo $phone; ?></span>
        <strong>Car Booked:</strong> <span><?php echo $car; ?></span>
        <strong>Booking Date:</strong> <span><?php echo $date; ?></span>
        <strong>Pickup Location:</strong> <span><?php echo $location; ?></span>
        <p>✅ Your car has been successfully booked. Please carry this certificate on the pickup day.</p>
        <button class="print-btn" onclick="window.print()">🖨️ Print Certificate</button>
    </div>
</div>

</body>
</html>
