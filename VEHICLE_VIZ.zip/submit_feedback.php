<?php
$success = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Connect to MySQL
    $conn = new mysqli("localhost", "root", "", "car_management");

    if ($conn->connect_error) {
        $error = "Database connection failed: " . $conn->connect_error;
    } else {
        // Sanitize inputs
        $name = $conn->real_escape_string(trim($_POST['name']));
        $email = $conn->real_escape_string(trim($_POST['email']));
        $rating = (int)$_POST['rating'];
        $comments = $conn->real_escape_string(trim($_POST['comments']));

        // Validate rating
        if ($rating < 1 || $rating > 5) {
            $error = "Invalid rating selected.";
        } else {
            // Insert query
            $sql = "INSERT INTO feedback (name, email, rating, comments)
                    VALUES ('$name', '$email', $rating, '$comments')";

            if ($conn->query($sql) === TRUE) {
                $success = "Thank you for your feedback!";
            } else {
                $error = "Error: " . $conn->error;
            }
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Feedback</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f5f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .feedback-form {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            max-width: 450px;
            width: 100%;
        }

        .feedback-form h2 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #1e88e5;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #1565c0;
        }

        .message {
            text-align: center;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .message.success {
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
</head>
<body>

<div class="feedback-form">
    <h2>Customer Feedback</h2>

    <?php if ($success): ?>
        <p class="message success"><?= $success ?></p>
    <?php elseif ($error): ?>
        <p class="message error"><?= $error ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <div class="form-group">
            <label for="name">Your Name:</label>
            <input type="text" name="name" id="name" required placeholder="Enter full name">
        </div>

        <div class="form-group">
            <label for="email">Email Address:</label>
            <input type="email" name="email" id="email" required placeholder="example@domain.com">
        </div>

        <div class="form-group">
            <label for="rating">Rating:</label>
            <select name="rating" id="rating" required>
                <option value="">-- Choose Rating --</option>
                <option value="5">5 - Excellent</option>
                <option value="4">4 - Very Good</option>
                <option value="3">3 - Good</option>
                <option value="2">2 - Fair</option>
                <option value="1">1 - Poor</option>
            </select>
        </div>

        <div class="form-group">
            <label for="comments">Feedback / Comments:</label>
            <textarea name="comments" id="comments" placeholder="Your suggestions..."></textarea>
        </div>

        <button type="submit">Submit Feedback</button>
    </form>
</div>

</body>
</html>
