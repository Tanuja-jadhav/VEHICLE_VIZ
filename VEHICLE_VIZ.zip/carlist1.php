<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: VIZ_login.php");
    exit;
}
error_reporting(0);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "details";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM car_details";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Booking - Vehicle Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f8f8f8; }
        header { background-color: white; padding: 10px; text-align: center; }
        header h1 { color: blue; font-size: 30px; }
        nav { background-color: black; padding: 10px; display: flex; justify-content: space-between; align-items: center; }
        nav a { color: white; margin: 0 15px; text-decoration: none; font-weight: bold; }
        nav .user-box { color: white; display: flex; gap: 15px; align-items: center; }
        .search-box input[type="text"] { padding: 5px; border-radius: 4px; }

        h1 { text-align: center; margin-top: 20px; }

        input[type="text"]#searchInput {
            width: 50%;
            padding: 10px;
            margin: 20px auto;
            display: block;
            font-size: 16px;
            border-radius: 20px;
            border: 1px solid #ccc;
        }

        .car-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 0 20px 40px;
        }

        .car {
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 10px;
            text-align: center;
            width: 220px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        .car img {
            width: 100%;
            height: 130px;
            object-fit: cover;
            border-radius: 6px;
        }

        .car p {
            font-weight: bold;
            margin: 10px 0;
        }

        .car button {
            background: #007BFF;
            color: white;
            padding: 6px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        footer {
            text-align: center;
            padding: 15px;
            background: #eee;
        }
    </style>
</head>
<body>

<header>
    <h1>Vehicle Management System</h1>
    <div>Welcome, Vehicle Management System</div>
</header>

<nav>
    <div>
        <a href="UI.php">HOME</a>
        <a href="carlisting.php">CAR LISTING</a>
        <a href="VIZ_logout.php">LOGOUT</a>
    </div>
    <div class="user-box">
        <?php echo htmlspecialchars($_SESSION['user']); ?>
        <form method="get" action="search.php" class="search-box">
            <input type="text" name="q" placeholder="Search...">
        </form>
    </div>
</nav>

<h1>Find Your Car</h1>

<input type="text" id="searchInput" placeholder="Type car name..." onkeyup="searchCar()">

<div class="car-list" id="carList">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $name = htmlspecialchars($row['NAME']);
            $image = htmlspecialchars($row['IMAGE']);
            $description = htmlspecialchars($row['DESCRIPTION']);
            $details = htmlspecialchars($row['DETAILS']);
            echo "
            <div class='car' data-name='{$name}'>
                <img src='{$image}' alt='{$name}'>
                <p>{$name}</p>
                <button onclick=\"viewDetails('{$name}', '{$description}', '{$details}')\">View Details</button>
            </div>";
        }
    } else {
        echo "<p>No cars found.</p>";
    }
    $conn->close();
    ?>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Vehicle Management System
</footer>

<script>
    function searchCar() {
        const input = document.getElementById("searchInput").value.toLowerCase();
        const cars = document.querySelectorAll(".car");

        cars.forEach(car => {
            const carName = car.getAttribute("data-name").toLowerCase();
            car.style.display = carName.includes(input) ? "block" : "none";
        });
    }

    function viewDetails(name, description, price) {
        localStorage.setItem("carName", name);
        localStorage.setItem("carDescription", description);
        localStorage.setItem("carPrice", price);
        window.location.href = "bookcar.php";
    }
</script>

</body>
</html>
