<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}
?>

<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', 0);

$connection = mysqli_connect("localhost:3307", "root", "", "vehicle");
if (!$connection) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($connection, "DELETE FROM customer WHERE CUSTOMER_ID = '$id'");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$result = mysqli_query($connection, "SELECT * FROM customer");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Customer Records - Admin Panel</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

  <!-- Header -->
  <header class="bg-white shadow-md py-4 px-8 flex items-center justify-between">
    <div class="flex items-center space-x-4">
      <img src="https://img.icons8.com/ios-filled/50/000000/car--v1.png" class="h-8 w-8" alt="Logo">
      <h1 class="text-xl font-bold text-gray-800">Car Showroom Admin Panel</h1>
    </div>
    <nav class="space-x-6">
      <a href="projectadmindash.php" class="text-gray-700 hover:text-black font-medium">Dashboard</a>
      <a href="vehiclerecord.php" class="text-gray-700 hover:text-black font-medium">Inventory</a>
      <a href="projectadmincustomerrecord.php" class="text-gray-700 hover:text-black font-medium">Customers</a>
      <a href="adminlogin.php" class="text-red-600 hover:text-red-800 font-semibold">Logout</a>
    </nav>
  </header>

  <!-- Main Body -->
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-gray-800 text-white flex flex-col py-6 px-4">
      <h2 class="text-2xl font-bold text-center mb-6">Admin Menu</h2>
      <nav class="space-y-2">
        <a href="projectadmindash.php" class="block py-2 px-3 rounded hover:bg-gray-700">Dashboard</a>
        <a href="projectaddemployee.php" class="block py-2 px-3 rounded hover:bg-gray-700">Manage Employees</a>
        <a href="vehiclerecord.php" class="block py-2 px-3 rounded hover:bg-gray-700">Vehicle Records</a>
		  <a href="add_cars2.php">🚗 Add Vehicle</a>
        <a href="projectvehiclemanage.php" class="block py-2 px-3 rounded hover:bg-gray-700">Manage Vehicles</a>
        <a href="projectadmincustomer.php" class="block py-2 px-3 rounded hover:bg-gray-700">Add Customer</a>
        <a href="projectadmincustomerrecord.php" class="block py-2 px-3 rounded bg-gray-700">Customer Records</a>
        <a href="projectadminsold.php" class="block py-2 px-3 rounded hover:bg-gray-700">Sold Vehicles</a>
        <a href="adminlogin.php" class="block py-2 px-3 rounded hover:bg-gray-700">Logout</a>
      </nav>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-8">
      <div class="flex justify-between items-center mb-6">
        <h2 class="text-3xl font-bold text-gray-800">Customer Records</h2>
        <div>
          <a href="projectadmincustomer.php" class="text-gray-600 hover:underline mr-4">← Add Customer</a>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow p-6 overflow-x-auto">
        <table class="min-w-full table-auto border border-gray-200">
          <thead class="bg-gray-200 text-gray-700">
            <tr>
              <th class="px-4 py-2 border">ID</th>
              <th class="px-4 py-2 border">Name</th>
              <th class="px-4 py-2 border">Address</th>
              <th class="px-4 py-2 border">Mobile No</th>
              <th class="px-4 py-2 border">Email</th>
              <th class="px-4 py-2 border">Vehicle</th>
              <th class="px-4 py-2 border">Purchase Date</th>
              <th class="px-4 py-2 border">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
              <tr class="text-center hover:bg-gray-100">
                <td class="px-4 py-2 border"><?php echo $row['CUSTOMER_ID']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['NAME']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['ADDRESS']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['MOBILE_NO']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['EMAIL']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['VEHICLE_PURCHASED']; ?></td>
                <td class="px-4 py-2 border"><?php echo $row['PURCHASE_DATE']; ?></td>
                <td class="px-4 py-2 border">
                  <a href="?delete=<?php echo $row['CUSTOMER_ID']; ?>" onclick="return confirm('Are you sure to delete?')" class="text-red-600 hover:text-red-800">Delete</a>
                </td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
