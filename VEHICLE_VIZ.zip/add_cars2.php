<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: adminlogin.php");
    exit;
}

// Database connection
$conn = new mysqli("localhost:3307", "root", "", "details");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";
$errorMsg = "";
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $year = intval($_POST["model_year"]);
    $description = trim($_POST["description"]);
    $details = trim($_POST["details"]);
    $remaining_material = trim($_POST["remaining_material"]);
    $accident = $_POST["accident"] ?? '';
    $tyres = $_POST["tyres"] ?? '';
    $scratch = $_POST["scratch"] ?? '';
    $door_seal = $_POST["door_seal"] ?? '';
    $engine = $_POST["engine"] ?? '';
    $servicing = $_POST["servicing"] ?? '';

    if (!$name || !$year || !$description || !$details || !$remaining_material ||
        !$accident || !$tyres || !$scratch || !$door_seal || !$engine || !$servicing) {
        $errorMsg = "❗ Please fill in all the fields.";
    } elseif (!isset($_FILES["image"]) || $_FILES["image"]["error"] !== UPLOAD_ERR_OK) {
        $errorMsg = "❗ Please upload an image.";
    } else {
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
        $fileTmpPath = $_FILES["image"]["tmp_name"];
        $fileName = basename($_FILES["image"]["name"]);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (!in_array($fileExt, $allowedTypes)) {
            $errorMsg = "❌ Only JPG, JPEG, PNG, and GIF files are allowed.";
        } else {
            $newFileName = time() . "_" . preg_replace("/[^a-zA-Z0-9_-]/", "_", pathinfo($fileName, PATHINFO_FILENAME)) . "." . $fileExt;
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $sql = "INSERT INTO car_bookings 
                        (NAME, YEAR, IMAGE, DESCRIPTION, DETAILS, ACCIDENT, TYRES, SCRATCH, DOOR_SEAL, ENGINE, SERVICING, REMAINING_MATERIAL) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                if ($stmt) {
                    $stmt->bind_param("sissssssssss", $name, $year, $destPath, $description, $details, $accident, $tyres, $scratch, $door_seal, $engine, $servicing, $remaining_material);
                    if ($stmt->execute()) {
                        $successMsg = "✅ Car added successfully!";
                    } else {
                        $errorMsg = "❌ Failed to add car: " . $stmt->error;
                        unlink($destPath);
                    }
                    $stmt->close();
                } else {
                    $errorMsg = "❌ Prepare failed: " . $conn->error;
                    unlink($destPath);
                }
            } else {
                $errorMsg = "❌ Failed to upload the image.";
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin - Add Car</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body { background-color: #f8f9fa; }
    .sidebar { height: 100vh; background-color: #343a40; color: white; }
    .sidebar a { color: white; text-decoration: none; display: block; padding: 15px; }
    .sidebar a:hover { background-color: #495057; }
    .form-container { background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 6px 12px rgba(0,0,0,0.1); }
    .radio-group { display: flex; gap: 20px; margin-bottom: 10px; }
</style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-2 sidebar d-flex flex-column p-0">
            <h4 class="text-center mt-4">Admin Panel</h4>
            <a href="#">Dashboard</a>
            <a href="projectaddemployee.php">Manage Employee</a>
            <a href="vehiclerecord.php">Vehicle Record</a>
            <a href="projectvehiclemanage.php">Vehicle Management</a>
            <a href="add_cars2.php" class="bg-primary">Add Vehicle</a>
            <a href="projectadmincustomer.php">Customers</a>
            <a href="projectadmincustomerrecord.php">Customers Records</a>
            <a href="projectadminsold.php">Sold Vehicles</a>
            <a href="projectadminloanrecord.php">Loan Application Record</a>
            <a href="projectadminaddmaintainance.php">Maintenance</a>
            <a href="admin_view_feedback.php">View Customer Feedback</a>
            <a href="adminlogout.php">Logout</a>
        </div>

        <!-- Main Content -->
        <div class="col-md-10 p-4">
            <h2>Add New Car</h2>

            <?php if ($successMsg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($successMsg) ?></div>
            <?php endif; ?>
            <?php if ($errorMsg): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($errorMsg) ?></div>
            <?php endif; ?>

            <div class="form-container mt-3">
                <form method="POST" enctype="multipart/form-data">
                    <label>Car Name:</label>
                    <input type="text" name="name" pattern="[A-Za-z]+" class="form-control" required>

                    <label>Upload Image:</label>
                    <input type="file" name="image" accept="image/*" class="form-control" required>

                    <label>Description:</label>
                    <textarea name="description" rows="3" class="form-control" required></textarea>

                    <label>Details:</label>
                    <textarea name="details" rows="4" class="form-control" required></textarea>

                    <label>Accident:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="accident" value="yes" required> Yes</label>
                        <label><input type="radio" name="accident" value="no"> No</label>
                    </div>

                    <label>Tyres:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="tyres" value="new" required> New</label>
                        <label><input type="radio" name="tyres" value="old"> Old</label>
                    </div>

                    <label>Scratch:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="scratch" value="yes" required> Yes</label>
                        <label><input type="radio" name="scratch" value="no"> No</label>
                    </div>

                    <label>Model Year:</label>
                    <select name="model_year" class="form-control" required>
                        <?php
                        $currentYear = date("Y");
                        for ($y = $currentYear; $y >= 1980; $y--) {
                            echo "<option value=\"$y\">$y</option>";
                        }
                        ?>
                    </select>

                    <label>Door Seal:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="door_seal" value="yes" required> Yes</label>
                        <label><input type="radio" name="door_seal" value="no"> No</label>
                    </div>

                    <label>Engine:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="engine" value="new" required> New</label>
                        <label><input type="radio" name="engine" value="old"> Old</label>
                    </div>

                    <label>Servicing:</label>
                    <div class="radio-group">
                        <label><input type="radio" name="servicing" value="showroom" required> Showroom</label>
                        <label><input type="radio" name="servicing" value="local"> Local</label>
                    </div>

                    <label>Remaining Material:</label>
                    <textarea name="remaining_material" rows="3" class="form-control" required></textarea>

                    <button type="submit" class="btn btn-primary mt-3">Add Car</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
